package com.darkpresence;

import com.darkpresence.entity.ModEntities;
import com.darkpresence.events.RandomEventHandler;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.*;

public class DarkPresenceMod implements ModInitializer {

    public static final String MOD_ID = "darkpresence";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final String[] JOIN_FIRST = {
        "§4§l[ DARK PRESENCE ]§r §cseni bekliyordum.",
        "§4§l[ DARK PRESENCE ]§r §csonunda geldin.",
        "§4§l[ DARK PRESENCE ]§r §cbiliyorum seni.",
        "§4§l[ DARK PRESENCE ]§r §cseni duyabiliyorum.",
        "§4§l[ DARK PRESENCE ]§r §ctek degilsin burada.",
    };

    private static final String[] JOIN_RETURN = {
        "§4§l[ DARK PRESENCE ]§r §8yine mi geldin.",
        "§4§l[ DARK PRESENCE ]§r §8merak ettim nereye gitmistin.",
        "§4§l[ DARK PRESENCE ]§r §8geri dondugun icin mutluyum.",
        "§4§l[ DARK PRESENCE ]§r §8seni hic birakmiyor bu yer deil mi.",
    };

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModSounds.register();
        ServerTickEvents.END_SERVER_TICK.register(new RandomEventHandler());

        // stare timer tick
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (DarkPresenceState.stareTimer > 0) {
                DarkPresenceState.stareTimer--;
                if (DarkPresenceState.stareTimer <= 0)
                    DarkPresenceState.stareTarget = null;
            }
        });

        // dünyaya girilince
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.player;
            String name = player.getName().getString();

            server.execute(() -> {
                // 1 dakika geçip geçmediğini dünya zamanından ölç
                // world time > 1200 tick = 1 dakika oynandı demek
                long worldTime = server.getOverworld().getTime();
                boolean returning = worldTime > 1200 || isReturningPlayer(server.getRunDirectory().toString(), name);

                if (!returning) {
                    // ilk kez
                    DarkPresenceState.firstTimeThisSession = true;
                    saveVisit(server.getRunDirectory().toString(), name);
                    int idx = (int)(Math.random() * JOIN_FIRST.length);
                    String msg = JOIN_FIRST[idx];
                    if (Math.random() < 0.5)
                        msg = msg.replace(".", ", §8" + corruptName(name) + "§c.");
                    player.sendMessage(Text.literal(msg), false);
                } else {
                    // dönen oyuncu
                    int idx = (int)(Math.random() * JOIN_RETURN.length);
                    player.sendMessage(Text.literal(JOIN_RETURN[idx]), false);
                }
            });
        });

        // ilk mob öldürme
        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((world, killer, killed) -> {
            if (!(killer instanceof ServerPlayerEntity sp)) return;
            if (DarkPresenceState.firstKillDone) return;
            if (!(killed instanceof LivingEntity)) return;
            // vanilla mob mu kontrol et (mod entityleri değil)
            String id = net.minecraft.registry.Registries.ENTITY_TYPE.getId(killed.getType()).getNamespace();
            if (!id.equals("minecraft")) return;

            DarkPresenceState.firstKillDone = true;
            String name = sp.getName().getString();

            sp.sendMessage(Text.literal("§8neden beni oldurdun"), false);
            sp.sendMessage(Text.literal("§4§lseni her yerden izliyorum, " + name), false);
            sp.playSound(ModSounds.AMBIENT_WHISPER, 1.5f, 0.5f);

            // tüm entityler 2 dakika oyuncuya baksın (2400 tick)
            DarkPresenceState.stareTarget = sp;
            DarkPresenceState.stareTimer = 2400;
        });
    }

    private boolean isReturningPlayer(String runDir, String playerName) {
        try {
            Path f = Path.of(runDir, "darkpresence_" + playerName + ".dat");
            return Files.exists(f);
        } catch (Exception e) { return false; }
    }

    private void saveVisit(String runDir, String playerName) {
        try {
            Path f = Path.of(runDir, "darkpresence_" + playerName + ".dat");
            Files.writeString(f, "visited");
        } catch (Exception ignored) {}
    }

    private String corruptName(String name) {
        StringBuilder sb = new StringBuilder();
        for (char c : name.toCharArray())
            sb.append(Math.random() < 0.25 ? (char)(c+1) : c);
        return sb.toString();
    }
}
