package com.darkpresence;

import net.minecraft.server.network.ServerPlayerEntity;

// paylaşılan mod durumu - tüm entity'ler buradan okur
public class DarkPresenceState {

    // tüm entitylerin bakacağı oyuncu + süre (tick)
    public static ServerPlayerEntity stareTarget = null;
    public static int stareTimer = 0;

    // bu oturumda ilk kez mi girildi
    public static boolean firstTimeThisSession = false;

    // ilk kill yapıldı mı bu oturumda
    public static boolean firstKillDone = false;
}
