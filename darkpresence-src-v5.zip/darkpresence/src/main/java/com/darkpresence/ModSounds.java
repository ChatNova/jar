package com.darkpresence;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {

    public static final SoundEvent WATCHER_BREATHE = reg("watcher_breathe");
    public static final SoundEvent WATCHER_VANISH  = reg("watcher_vanish");

    public static final SoundEvent CRAWLER_SCREECH = reg("crawler_screech");
    public static final SoundEvent CRAWLER_SCUTTLE = reg("crawler_scuttle");

    public static final SoundEvent HOLLOW_MOAN     = reg("hollow_moan");
    public static final SoundEvent HOLLOW_SNAP     = reg("hollow_snap");

    public static final SoundEvent MIRROR_LAUGH    = reg("mirror_laugh");
    public static final SoundEvent MIRROR_MIMIC    = reg("mirror_mimic");

    public static final SoundEvent AMBIENT_STATIC  = reg("ambient_static");
    public static final SoundEvent AMBIENT_WHISPER = reg("ambient_whisper");
    public static final SoundEvent AMBIENT_HB      = reg("ambient_heartbeat");

    private static SoundEvent reg(String name) {
        Identifier id = Identifier.of(DarkPresenceMod.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {}
}
