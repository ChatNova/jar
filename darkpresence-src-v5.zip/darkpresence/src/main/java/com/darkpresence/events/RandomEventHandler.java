package com.darkpresence.events;

import com.darkpresence.ModSounds;
import com.darkpresence.entity.ModEntities;
import com.darkpresence.entity.MirrorEntity;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.Random;

public class RandomEventHandler implements ServerTickEvents.EndTick {

    // ambient ses - her 3-7 dakikada bir arka planda çalar
    private static final int AMBIENT_MIN = 20 * 60 * 3;
    private static final int AMBIENT_MAX = 20 * 60 * 7;
    private int nextAmbient = 20 * 60 * 2;

    // ana event
    private static final int EVENT_MIN = 20 * 40;
    private static final int EVENT_MAX = 20 * 60 * 3;
    private int nextEvent;

    private int massSpawnCd = 20 * 60 * 15;

    private final Random rng = new Random();

    private static final String[] MSGS = {
        "§8neden buraya geldin",
        "§8beni goriyor musun",
        "§8cok guzel bir geceydi",
        "§8git artik",
        "§8dur. dur. dur. dur.",
        "§8seni duyuyorum",
        "§8arka tarafina bak",
        "§8§oBEN TAM ARKANDAYIM§r",
        "§8icerideyim",
        "§4kapiyi kilitledin mi",
        "§4seni izledim",
        "§4uyuma bu gece",
        "§8ha ha ha ha ha ha",
        "§4§lGIT.",
        "§8nefes sesini duyabiliyorum",
        "§4§lDON.",
    };

    public RandomEventHandler() {
        nextEvent = 20 * 30 + rng.nextInt(20 * 60);
    }

    @Override
    public void onEndTick(MinecraftServer server) {
        long tick = server.getTicks();
        massSpawnCd--;

        List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList()
            .stream().filter(p -> !p.isCreative() && !p.isSpectator()).toList();

        if (players.isEmpty()) {
            nextEvent = (int) tick + EVENT_MIN;
            nextAmbient = (int) tick + AMBIENT_MIN;
            return;
        }

        ServerPlayerEntity p = players.get(rng.nextInt(players.size()));

        // ambient arka plan sesi - çok hafif, fark edilmeyecek seviyede
        if (tick >= nextAmbient) {
            doAmbientSound(p);
            nextAmbient = (int) tick + AMBIENT_MIN + rng.nextInt(AMBIENT_MAX - AMBIENT_MIN);
        }

        // ana event
        if (tick >= nextEvent) {
            if (massSpawnCd <= 0 && rng.nextFloat() < 0.1f) {
                doMassSpawn(p);
                massSpawnCd = 20 * 60 * 20;
            } else {
                triggerEvent(p, rng.nextInt(20));
            }
            nextEvent = (int) tick + EVENT_MIN + rng.nextInt(EVENT_MAX - EVENT_MIN);
        }
    }

    // hafif ambient ses - oyuncu fark etmeyebilir
    private void doAmbientSound(ServerPlayerEntity p) {
        int s = rng.nextInt(4);
        switch (s) {
            case 0 -> p.playSound(ModSounds.AMBIENT_WHISPER, 0.25f, 0.9f);
            case 1 -> p.playSound(ModSounds.AMBIENT_HB,      0.3f,  0.5f);
            case 2 -> p.playSound(ModSounds.AMBIENT_STATIC,  0.2f,  1.2f);
            case 3 -> p.playSound(ModSounds.WATCHER_BREATHE, 0.15f, 0.7f);
        }
    }

    private void triggerEvent(ServerPlayerEntity p, int type) {
        ServerWorld w = p.getServerWorld();

        switch (type) {

            // static + karartma
            case 0 -> {
                p.playSound(ModSounds.AMBIENT_STATIC, 1.3f, 0.75f);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 40, 1));
            }

            // fısıltı mesajı
            case 1 -> {
                p.sendMessage(Text.literal(MSGS[rng.nextInt(MSGS.length)]), false);
                p.playSound(ModSounds.AMBIENT_WHISPER, 0.8f, 0.8f);
            }

            // watcher uzakta izliyor (görünür mesafe)
            case 2 -> spawnWatcher(w, p, 18, 30);

            // watcher TAM arkasında 2 blok
            case 3 -> {
                float yaw = p.getYaw() + 180;
                double a = Math.toRadians(yaw);
                var watcher = ModEntities.WATCHER.create(w);
                if (watcher != null) {
                    watcher.refreshPositionAndAngles(
                        p.getX() + Math.cos(a) * 2.0, p.getY(),
                        p.getZ() + Math.sin(a) * 2.0, 0, 0);
                    w.spawnEntity(watcher);
                    p.playSound(ModSounds.WATCHER_BREATHE, 2.0f, 0.3f);
                }
            }

            // crawler grubu
            case 4 -> {
                for (int i = 0; i < 2 + rng.nextInt(3); i++) {
                    var c = ModEntities.CRAWLER.create(w);
                    if (c != null) {
                        c.refreshPositionAndAngles(p.getBlockPos().add(
                            rng.nextInt(14)-7, 0, rng.nextInt(14)-7), 0, 0);
                        w.spawnEntity(c);
                    }
                }
                p.playSound(ModSounds.CRAWLER_SCREECH, 1.2f, 0.5f);
            }

            // donma + kalp atışı
            case 5 -> {
                p.playSound(ModSounds.AMBIENT_HB, 1.5f, 0.4f);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,       140, 255, false, false));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 140, 255, false, false));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS,        70, 1));
                p.sendMessage(Text.literal("§8..."), false);
            }

            // hollow gece + grubu
            case 6 -> {
                if (!w.isDay()) {
                    for (int i = 0; i < 3; i++) {
                        var h = ModEntities.HOLLOW.create(w);
                        if (h != null) {
                            h.refreshPositionAndAngles(p.getBlockPos().add(
                                rng.nextInt(24)-12, 0, rng.nextInt(24)-12), 0, 0);
                            w.spawnEntity(h);
                        }
                    }
                    p.sendMessage(Text.literal("§8§oonlar burada§r"), false);
                    p.playSound(ModSounds.HOLLOW_MOAN, 1.2f, 0.5f);
                } else {
                    // gündüzse watcher
                    spawnWatcher(w, p, 12, 22);
                }
            }

            // mirror - uzaktan izliyor (görünür mesafe ~20 blok)
            case 7 -> spawnMirror(w, p, 16, 24);

            // title - bozuk isim
            case 8 -> {
                String name = p.getName().getString();
                p.networkHandler.sendPacket(new TitleFadeS2CPacket(3, 50, 15));
                p.networkHandler.sendPacket(new TitleS2CPacket(
                    Text.literal(corruptText(name)).formatted(Formatting.DARK_RED)));
                p.networkHandler.sendPacket(new SubtitleS2CPacket(
                    Text.literal("§8seni goruyorum")));
                p.playSound(ModSounds.AMBIENT_STATIC, 1.5f, 0.4f);
            }

            // körlük + bulantı
            case 9 -> {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA,    80, 0));
                p.playSound(ModSounds.WATCHER_BREATHE, 1.2f, 0.35f);
                p.sendMessage(Text.literal("§4§lGOZLERINI KAPAT"), false);
            }

            // 5 watcher çemberi
            case 10 -> {
                for (int i = 0; i < 5; i++) spawnWatcher(w, p, 12+i*4, 22+i*4);
                p.playSound(ModSounds.AMBIENT_STATIC, 2.0f, 0.3f);
            }

            // obsidian yağmuru + hafif hasar
            case 11 -> {
                w.spawnParticles(ParticleTypes.DRIPPING_OBSIDIAN_TEAR,
                    p.getX(), p.getY() + 5, p.getZ(), 90, 3.0, 0.2, 3.0, 0.02);
                p.damage(p.getDamageSources().generic(), 3f);
                p.playSound(ModSounds.AMBIENT_HB, 1.0f, 0.4f);
            }

            // isim spam chat
            case 12 -> {
                for (int i = 0; i < 6; i++)
                    p.sendMessage(Text.literal("§8" + corruptText(p.getName().getString())), false);
                p.playSound(ModSounds.MIRROR_LAUGH, 0.9f, 0.6f);
            }

            // crawler tam üstten düşüyor
            case 13 -> {
                var c = ModEntities.CRAWLER.create(w);
                if (c != null) {
                    c.refreshPositionAndAngles(p.getX(), p.getY()+4, p.getZ(), 0, 0);
                    w.spawnEntity(c);
                    p.playSound(ModSounds.CRAWLER_SCREECH, 1.5f, 0.45f);
                }
            }

            // 2 mirror farklı açılardan
            case 14 -> {
                p.playSound(ModSounds.AMBIENT_WHISPER, 1.1f, 0.65f);
                spawnMirror(w, p, 12, 18);
                spawnMirror(w, p, 18, 26);
            }

            // tam körlük dalgası
            case 15 -> {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 220, 255, false, false));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 220, 1, false, false));
                p.networkHandler.sendPacket(new TitleFadeS2CPacket(2, 100, 10));
                p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("§0§l.")));
                p.playSound(ModSounds.HOLLOW_SNAP, 1.5f, 0.3f);
                spawnWatcher(w, p, 3, 7);
            }

            // "burada mısın?" + IP
            case 16 -> {
                spawnWatcher(w, p, 6, 14);
                String ip = p.getIp();
                p.networkHandler.sendPacket(new TitleFadeS2CPacket(5, 70, 20));
                p.networkHandler.sendPacket(new TitleS2CPacket(
                    Text.literal("burada misin?").formatted(Formatting.DARK_RED, Formatting.BOLD)));
                p.networkHandler.sendPacket(new SubtitleS2CPacket(
                    Text.literal(ip).formatted(Formatting.GRAY)));
                p.sendMessage(Text.literal("§4[?] §8" + ip), false);
                p.playSound(ModSounds.AMBIENT_STATIC, 1.8f, 0.4f);
            }

            // hollow TAM arkasına
            case 17 -> {
                float yaw = p.getYaw() + 180;
                double a = Math.toRadians(yaw);
                var h = ModEntities.HOLLOW.create(w);
                if (h != null) {
                    h.refreshPositionAndAngles(
                        p.getX() + Math.cos(a)*1.8, p.getY(),
                        p.getZ() + Math.sin(a)*1.8, 0, 0);
                    w.spawnEntity(h);
                    p.playSound(ModSounds.HOLLOW_SNAP, 1.5f, 0.6f);
                }
            }

            // chunk flicker simülasyonu - karartma flaşları
            case 18 -> {
                // hızlı karartma + statik - sanki chunk düşüyor gibi
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 8,  2, false, false));
                p.playSound(ModSounds.AMBIENT_STATIC, 1.0f, 1.5f);
                p.sendMessage(Text.literal("§8§o..."), false);
                // 1 saniye sonra tekrar
                p.getServer().execute(() -> {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 6, 2, false, false));
                    p.playSound(ModSounds.AMBIENT_STATIC, 0.8f, 1.8f);
                });
            }

            // watcher + hollow birlikte gece ortasında
            case 19 -> {
                if (!w.isDay()) {
                    spawnWatcher(w, p, 8, 15);
                    var h = ModEntities.HOLLOW.create(w);
                    if (h != null) {
                        h.refreshPositionAndAngles(p.getBlockPos().add(
                            rng.nextInt(10)-5, 0, rng.nextInt(10)-5), 0, 0);
                        w.spawnEntity(h);
                    }
                    p.sendMessage(Text.literal("§8ikisi de burada"), false);
                    p.playSound(ModSounds.HOLLOW_MOAN, 1.0f, 0.6f);
                }
            }
        }
    }

    // wonderland tarzı - sürü
    private void doMassSpawn(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        p.networkHandler.sendPacket(new TitleFadeS2CPacket(5, 90, 20));
        p.networkHandler.sendPacket(new TitleS2CPacket(
            Text.literal("§4§l" + corruptText(p.getName().getString()))));
        p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal("§8kac")));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 160, 1));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA,    80, 1));
        p.playSound(ModSounds.AMBIENT_STATIC, 2.0f, 0.3f);

        for (int i = 0; i < 7; i++) spawnWatcher(w, p, 6+i*3, 14+i*3);
        for (int i = 0; i < 6; i++) {
            var c = ModEntities.CRAWLER.create(w);
            if (c != null) {
                c.refreshPositionAndAngles(p.getBlockPos().add(rng.nextInt(22)-11, 0, rng.nextInt(22)-11), 0, 0);
                w.spawnEntity(c);
            }
        }
        for (int i = 0; i < 4; i++) spawnMirror(w, p, 8+i*4, 16+i*4);
        for (int i = 0; i < 4; i++) {
            var h = ModEntities.HOLLOW.create(w);
            if (h != null) {
                h.refreshPositionAndAngles(p.getBlockPos().add(rng.nextInt(18)-9, 0, rng.nextInt(18)-9), 0, 0);
                w.spawnEntity(h);
            }
        }
        for (int i = 0; i < 8; i++)
            p.sendMessage(Text.literal("§4" + corruptText(p.getName().getString())), false);
    }

    private void spawnWatcher(ServerWorld w, ServerPlayerEntity p, double minD, double maxD) {
        for (int i = 0; i < 20; i++) {
            double a  = rng.nextDouble() * Math.PI * 2;
            double d  = minD + rng.nextDouble() * (maxD - minD);
            double nx = p.getX() + Math.cos(a) * d;
            double nz = p.getZ() + Math.sin(a) * d;
            double ny = w.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int)nx, (int)nz);
            if (w.getBlockState(new BlockPos((int)nx, (int)ny, (int)nz)).isAir()) {
                var watcher = ModEntities.WATCHER.create(w);
                if (watcher != null) {
                    watcher.refreshPositionAndAngles(nx, ny, nz, 0, 0);
                    w.spawnEntity(watcher);
                }
                break;
            }
        }
    }

    private void spawnMirror(ServerWorld w, ServerPlayerEntity p, double minD, double maxD) {
        double a  = rng.nextDouble() * Math.PI * 2;
        double d  = minD + rng.nextDouble() * (maxD - minD);
        double nx = p.getX() + Math.cos(a) * d;
        double nz = p.getZ() + Math.sin(a) * d;
        double ny = w.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int)nx, (int)nz);
        MirrorEntity m = ModEntities.MIRROR.create(w);
        if (m != null) {
            m.setTargetPlayerName(p.getName().getString());
            m.refreshPositionAndAngles(nx, ny, nz, 0, 0);
            w.spawnEntity(m);
            p.playSound(ModSounds.MIRROR_LAUGH, 0.8f, 0.9f);
        }
    }

    private String corruptText(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray())
            sb.append(rng.nextFloat() < 0.4f ? (char)(c + rng.nextInt(5) - 2) : c);
        return sb.toString();
    }
}
