package com.darkpresence.util;

// txt dosyası oluşturma kaldırıldı
public class ShadowFileWriter {
    public static void write() {}
}
