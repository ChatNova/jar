package com.darkpresence.entity;

import com.darkpresence.DarkPresenceState;
import com.darkpresence.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

// yerde sürünen, hızlı, öfkeli. GOAL YOK.
public class CrawlerEntity extends HostileEntity {

    private int screechCd  = 0;
    private int burstTimer = 0;
    private boolean enraged = false;

    public CrawlerEntity(EntityType<? extends HostileEntity> t, World w) {
        super(t, w);
    }

    public static DefaultAttributeContainer.Builder createAttr() {
        return HostileEntity.createHostileAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 80.0)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 9.0)
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 50.0)
            .add(EntityAttributes.GENERIC_STEP_HEIGHT, 1.5)
            .add(EntityAttributes.GENERIC_ARMOR, 4.0)
            .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.6);
    }

    @Override protected void initGoals() {}

    @Override
    public void tick() {
        super.tick();
        screechCd--;
        burstTimer--;

        if (getWorld().isClient()) {
            if (enraged) {
                getWorld().addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                    getX(), getY()+0.1, getZ(), 0, 0.05, 0);
            }
            return;
        }

        if (!(getWorld() instanceof ServerWorld sw)) return;

        // stare modu
        if (DarkPresenceState.stareTimer > 0 && DarkPresenceState.stareTarget != null) {
            getLookControl().lookAt(DarkPresenceState.stareTarget, 30f, 30f);
            setVelocity(0, getVelocity().y, 0);
            return;
        }

        PlayerEntity target = findNearest(sw);
        if (target == null) return;

        double dist = distanceTo(target);
        getLookControl().lookAt(target, 30f, 30f);

        // öfke modu
        if (getHealth() < getMaxHealth() * 0.5f && !enraged) {
            enraged = true;
            playSound(ModSounds.CRAWLER_SCREECH, 2.0f, 0.4f);
        }

        // screech yakında
        if (dist < 12 && screechCd <= 0) {
            playSound(ModSounds.CRAWLER_SCREECH, 1.5f, 0.45f + random.nextFloat()*0.3f);
            screechCd = 60;
            burstTimer = 35;
            if (dist < 4 && target instanceof ServerPlayerEntity sp) {
                sp.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 60, 1));
                sp.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 40, 0));
            }
        }

        // hareket
        Vec3d dir = target.getPos().subtract(getPos()).normalize();
        double spd = enraged ? 0.48 : (burstTimer > 0 ? 0.40 : 0.24);
        setVelocity(dir.x * spd, getVelocity().y, dir.z * spd);

        // zıplama
        if (dist < 3.5 && isOnGround() && getWorld().getTime() % 10 == 0)
            setVelocity(getVelocity().x * 1.6, 0.55, getVelocity().z * 1.6);

        // scuttle sesi karanlıkta
        if (getWorld().getLightLevel(getBlockPos()) < 4 && getWorld().getTime() % 60 == 0)
            playSound(ModSounds.CRAWLER_SCUTTLE, 0.7f, 1.4f);

        // yakın hasar
        if (dist < 2.2 && getWorld().getTime() % 18 == 0) {
            target.damage(target.getDamageSources().generic(), 9f);
            if (target instanceof ServerPlayerEntity sp)
                sp.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 50, 0));
            playSound(ModSounds.CRAWLER_SCREECH, 1.1f, 0.55f);
        }
    }

    private PlayerEntity findNearest(ServerWorld sw) {
        PlayerEntity res = null; double best = 50.0;
        for (PlayerEntity p : sw.getPlayers()) {
            if (p.isCreative() || p.isSpectator()) continue;
            double d = distanceTo(p);
            if (d < best) { best = d; res = p; }
        }
        return res;
    }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.CRAWLER_SCUTTLE; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.CRAWLER_SCREECH; }
    @Override protected SoundEvent getDeathSound() { return ModSounds.CRAWLER_SCREECH; }
    @Override protected float getSoundVolume() { return 1.1f; }
}
