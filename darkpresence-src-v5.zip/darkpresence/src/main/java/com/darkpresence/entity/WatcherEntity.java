package com.darkpresence.entity;

import com.darkpresence.DarkPresenceState;
import com.darkpresence.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

// uzun, siyah gözlü. sadece bakıyor. GOAL YOK.
public class WatcherEntity extends HostileEntity {

    private static final float VANISH_DIST = 5.0f;
    private static final int   TP_COOLDOWN = 180;

    private int tpTimer    = 60;
    private int stareTimer = 0;
    private int ipShowCd   = 200;

    public WatcherEntity(EntityType<? extends HostileEntity> t, World w) {
        super(t, w);
        this.setInvulnerable(true);
        this.setSilent(false);
    }

    public static DefaultAttributeContainer.Builder createAttr() {
        return HostileEntity.createHostileAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 9999.0)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 80.0)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 7.0)
            .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override protected void initGoals() {}

    @Override
    public void tick() {
        super.tick();

        if (getWorld().isClient()) {
            for (int i = 0; i < 2; i++) {
                double rx = (random.nextDouble()-0.5)*1.4;
                double rz = (random.nextDouble()-0.5)*1.4;
                getWorld().addParticle(ParticleTypes.SOUL,
                    getX()+rx, getY()+random.nextDouble()*4.0, getZ()+rz,
                    0, 0.012, 0);
            }
            return;
        }

        if (!(getWorld() instanceof ServerWorld sw)) return;

        tpTimer++;
        stareTimer++;
        ipShowCd--;

        // global stare modu
        if (DarkPresenceState.stareTimer > 0 && DarkPresenceState.stareTarget != null) {
            getLookControl().lookAt(DarkPresenceState.stareTarget, 30f, 30f);
            setVelocity(0, getVelocity().y, 0);
            return;
        }

        PlayerEntity nearest = findNearest(sw);
        if (nearest == null) return;

        double dist = distanceTo(nearest);
        getLookControl().lookAt(nearest, 30f, 30f);
        setVelocity(0, getVelocity().y, 0); // watcher hiç hareket etmez

        if (dist < VANISH_DIST) {
            if (nearest instanceof ServerPlayerEntity sp && ipShowCd <= 0) {
                showIpTitle(sp);
                ipShowCd = 300;
            }
            doVanish(sw, nearest);
            return;
        }

        if (dist < 30 && stareTimer > 50 && isLookingAtMe(nearest)) {
            playSound(ModSounds.WATCHER_BREATHE, 0.6f, 0.6f);
            stareTimer = 0;
        }

        if (dist < 20 && ipShowCd <= 0 && nearest instanceof ServerPlayerEntity sp) {
            showIpTitle(sp);
            ipShowCd = 400;
        }

        if (tpTimer >= TP_COOLDOWN) {
            tpNear(sw, nearest);
            tpTimer = 0;
        }
    }

    private void showIpTitle(ServerPlayerEntity sp) {
        String ip = sp.getIp();
        sp.networkHandler.sendPacket(new TitleFadeS2CPacket(5, 80, 20));
        sp.networkHandler.sendPacket(new TitleS2CPacket(
            Text.literal("burada misin?").formatted(Formatting.DARK_RED, Formatting.BOLD)));
        sp.networkHandler.sendPacket(new SubtitleS2CPacket(
            Text.literal(ip).formatted(Formatting.GRAY)));
        sp.playSound(ModSounds.AMBIENT_STATIC, 1.5f, 0.4f);
        sp.sendMessage(Text.literal("§8+------------------+"), false);
        sp.sendMessage(Text.literal("§8|  §4burada misin?  §8|"), false);
        sp.sendMessage(Text.literal("§8|  §7" + ip + "  §8|"), false);
        sp.sendMessage(Text.literal("§8+------------------+"), false);
    }

    private void doVanish(ServerWorld sw, PlayerEntity p) {
        sw.spawnParticles(ParticleTypes.SOUL, getX(), getY()+2, getZ(), 30, 0.7, 1.6, 0.7, 0.09);
        playSound(ModSounds.WATCHER_VANISH, 1f, 0.45f);
        for (int i = 0; i < 20; i++) {
            double a = random.nextDouble()*Math.PI*2;
            double d = 35 + random.nextDouble()*30;
            double nx = p.getX()+Math.cos(a)*d;
            double nz = p.getZ()+Math.sin(a)*d;
            double ny = sw.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int)nx, (int)nz);
            if (sw.getBlockState(new BlockPos((int)nx, (int)ny, (int)nz)).isAir()) {
                teleport(nx, ny, nz, true); break;
            }
        }
        tpTimer = 0;
    }

    private void tpNear(ServerWorld sw, PlayerEntity p) {
        for (int i = 0; i < 24; i++) {
            double a = random.nextDouble()*Math.PI*2;
            double d = 10 + random.nextDouble()*14;
            double nx = p.getX()+Math.cos(a)*d;
            double nz = p.getZ()+Math.sin(a)*d;
            double ny = sw.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int)nx, (int)nz);
            if (sw.getBlockState(new BlockPos((int)nx, (int)ny, (int)nz)).isAir()) {
                teleport(nx, ny, nz, true);
                sw.spawnParticles(ParticleTypes.REVERSE_PORTAL, nx, ny+1, nz, 20, 0.4, 1.0, 0.4, 0.04);
                break;
            }
        }
    }

    private PlayerEntity findNearest(ServerWorld sw) {
        PlayerEntity res = null; double best = Double.MAX_VALUE;
        for (PlayerEntity p : sw.getPlayers()) {
            if (p.isCreative() || p.isSpectator()) continue;
            double d = distanceTo(p);
            if (d < best) { best = d; res = p; }
        }
        return res;
    }

    private boolean isLookingAtMe(PlayerEntity p) {
        Vec3d look = p.getRotationVec(1f).normalize();
        Vec3d tom  = getPos().subtract(p.getPos()).normalize();
        return look.dotProduct(tom) > 0.93;
    }

    @Override public boolean damage(DamageSource s, float a) { return false; }
    @Override public void onDeath(DamageSource s) {}
    @Override protected SoundEvent getAmbientSound() { return ModSounds.WATCHER_BREATHE; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return null; }
    @Override protected SoundEvent getDeathSound() { return null; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean cannotDespawn() { return true; }
    @Override protected boolean isDisallowedInPeaceful() { return false; }
}
