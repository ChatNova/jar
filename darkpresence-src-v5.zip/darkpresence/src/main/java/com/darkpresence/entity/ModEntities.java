package com.darkpresence.entity;

import com.darkpresence.DarkPresenceMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {

    // uzun, siyah gözlü steve. ana karakter. öldürülemiyor.
    public static final EntityType<WatcherEntity> WATCHER = Registry.register(
        Registries.ENTITY_TYPE,
        Identifier.of(DarkPresenceMod.MOD_ID, "watcher"),
        FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, WatcherEntity::new)
            .dimensions(EntityDimensions.fixed(0.6f, 3.8f))
            .build()
    );

    // yerde sürünen şey. hızlı, öfkeli.
    public static final EntityType<CrawlerEntity> CRAWLER = Registry.register(
        Registries.ENTITY_TYPE,
        Identifier.of(DarkPresenceMod.MOD_ID, "crawler"),
        FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, CrawlerEntity::new)
            .dimensions(EntityDimensions.fixed(1.4f, 0.4f))
            .build()
    );

    // başsız. bakınca duruyor. bakmazsan... bilmiyorum.
    public static final EntityType<HollowEntity> HOLLOW = Registry.register(
        Registries.ENTITY_TYPE,
        Identifier.of(DarkPresenceMod.MOD_ID, "hollow"),
        FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, HollowEntity::new)
            .dimensions(EntityDimensions.fixed(0.6f, 1.9f))
            .build()
    );

    // oyuncuya benziyor. tam olarak. ama gözleri yok.
    public static final EntityType<MirrorEntity> MIRROR = Registry.register(
        Registries.ENTITY_TYPE,
        Identifier.of(DarkPresenceMod.MOD_ID, "mirror"),
        FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, MirrorEntity::new)
            .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
            .build()
    );

    public static void register() {
        DarkPresenceMod.LOGGER.info("[dp] entityler yüklendi");
    }
}
