package com.darkpresence.entity;

import com.darkpresence.DarkPresenceState;
import com.darkpresence.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

// başsız. bakınca donar. bakmazsan koşar. GOAL YOK.
public class HollowEntity extends HostileEntity {

    private int moaning   = 0;
    private int snapCd    = 0;
    private int tpCd      = 60;
    private boolean wasWatched = false;

    public HollowEntity(EntityType<? extends HostileEntity> t, World w) {
        super(t, w);
    }

    public static DefaultAttributeContainer.Builder createAttr() {
        return HostileEntity.createHostileAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 100.0)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 11.0)
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 60.0)
            .add(EntityAttributes.GENERIC_ARMOR, 6.0)
            .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.8);
    }

    @Override protected void initGoals() {}

    @Override
    public void tick() {
        super.tick();
        moaning++;
        snapCd--;
        tpCd--;

        if (getWorld().isClient()) {
            for (int i = 0; i < 2; i++) {
                getWorld().addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                    getX() + (random.nextDouble()-0.5)*0.3,
                    getY() + 1.75,
                    getZ() + (random.nextDouble()-0.5)*0.3,
                    0, 0.04, 0);
            }
            return;
        }

        if (!(getWorld() instanceof ServerWorld sw)) return;

        // stare modu - tüm entityler oyuncuya baksın
        if (DarkPresenceState.stareTimer > 0 && DarkPresenceState.stareTarget != null) {
            getLookControl().lookAt(DarkPresenceState.stareTarget, 30f, 30f);
            setVelocity(0, getVelocity().y, 0);
            return;
        }

        PlayerEntity closest = findNearest(sw);
        if (closest == null) return;

        boolean watched = isPlayerLookingAtMe(closest);
        double dist = distanceTo(closest);

        getLookControl().lookAt(closest, 30f, 30f);

        if (watched) {
            setVelocity(0, getVelocity().y, 0);
            if (moaning % 40 == 0 && dist < 25)
                playSound(ModSounds.HOLLOW_MOAN, 0.5f, 0.7f);
            if (moaning % 80 == 0 && dist < 15 && closest instanceof ServerPlayerEntity sp) {
                String[] msgs = {"§8beni goriyor musun", "§8dur bakma", "§8gozlerini kapat"};
                sp.sendMessage(Text.literal(msgs[random.nextInt(msgs.length)]), false);
            }
            wasWatched = true;
        } else {
            // bakılmıyorsa hızlı hareket
            Vec3d dir = closest.getPos().subtract(getPos()).normalize();
            setVelocity(dir.x * 0.38, getVelocity().y, dir.z * 0.38);

            if (wasWatched && tpCd <= 0 && dist > 6) {
                // görüş kaybedilince tam arkasına git
                float yaw = closest.getYaw() + 180;
                double a = Math.toRadians(yaw);
                teleport(
                    closest.getX() + Math.cos(a) * (1.8 + random.nextDouble() * 2),
                    closest.getY(),
                    closest.getZ() + Math.sin(a) * (1.8 + random.nextDouble() * 2),
                    true);
                tpCd = 80;
                playSound(ModSounds.HOLLOW_SNAP, 1.5f, 0.5f);
            }
            if (dist < 6 && snapCd <= 0) {
                playSound(ModSounds.HOLLOW_SNAP, 0.5f, 1.2f);
                snapCd = 20;
            }
            wasWatched = false;
        }

        // yakın hasar
        if (dist < 2.5 && getWorld().getTime() % 20 == 0) {
            closest.damage(closest.getDamageSources().generic(), 11f);
            if (closest instanceof ServerPlayerEntity sp) {
                sp.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 1));
                sp.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 80, 1));
                sp.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
            }
            playSound(ModSounds.HOLLOW_SNAP, 1.5f, 0.45f);
        }
    }

    private boolean isPlayerLookingAtMe(PlayerEntity p) {
        Vec3d look = p.getRotationVec(1f).normalize();
        Vec3d toMe = getPos().subtract(p.getPos()).normalize();
        return look.dotProduct(toMe) > 0.85;
    }

    private PlayerEntity findNearest(ServerWorld sw) {
        PlayerEntity res = null; double best = 60.0;
        for (PlayerEntity p : sw.getPlayers()) {
            if (p.isCreative() || p.isSpectator()) continue;
            double d = distanceTo(p);
            if (d < best) { best = d; res = p; }
        }
        return res;
    }

    @Override public void onDeath(DamageSource s) {
        super.onDeath(s);
        if (getWorld() instanceof ServerWorld sw)
            sw.spawnParticles(ParticleTypes.SOUL, getX(), getY()+1, getZ(), 60, 0.8, 1.0, 0.8, 0.15);
    }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.HOLLOW_MOAN; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.HOLLOW_MOAN; }
    @Override protected SoundEvent getDeathSound() { return ModSounds.HOLLOW_SNAP; }
    @Override protected float getSoundVolume() { return 0.7f; }
}
