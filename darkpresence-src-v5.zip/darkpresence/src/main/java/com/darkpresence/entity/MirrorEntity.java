package com.darkpresence.entity;

import com.darkpresence.DarkPresenceState;
import com.darkpresence.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

// oyuncunun tam kopyası. gözleri yok. GOAL YOK.
public class MirrorEntity extends HostileEntity {

    private String targetName = "";
    private int mimicTimer = 0;
    private int laughCd    = 0;
    private int phaseCd    = 20*60*3;
    private int phase      = 0;
    private int chaseTicks = 0;
    private boolean chasing = false;

    public MirrorEntity(EntityType<? extends HostileEntity> t, World w) {
        super(t, w);
    }

    public static DefaultAttributeContainer.Builder createAttr() {
        return HostileEntity.createHostileAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 150.0)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 12.0)
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 70.0)
            .add(EntityAttributes.GENERIC_ARMOR, 10.0)
            .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override protected void initGoals() {}

    public void setTargetPlayerName(String name) { this.targetName = name; }

    @Override
    public void tick() {
        super.tick();
        mimicTimer++; laughCd--; chaseTicks--; phaseCd--;

        if (getWorld().isClient()) {
            getWorld().addParticle(ParticleTypes.FALLING_SPORE_BLOSSOM,
                getX()+0.18, getY()+1.60, getZ(), 0, 0.015, 0);
            getWorld().addParticle(ParticleTypes.FALLING_SPORE_BLOSSOM,
                getX()-0.18, getY()+1.60, getZ(), 0, 0.015, 0);
            if (phase == 2)
                getWorld().addParticle(ParticleTypes.SOUL, getX(), getY()+1, getZ(),
                    (random.nextDouble()-0.5)*0.3, 0.08, (random.nextDouble()-0.5)*0.3);
            return;
        }

        if (!(getWorld() instanceof ServerWorld sw)) return;

        // stare modu
        if (DarkPresenceState.stareTimer > 0 && DarkPresenceState.stareTarget != null) {
            getLookControl().lookAt(DarkPresenceState.stareTarget, 30f, 30f);
            setVelocity(0, getVelocity().y, 0);
            return;
        }

        PlayerEntity target = findTarget(sw);
        if (target == null) return;

        double dist = distanceTo(target);
        getLookControl().lookAt(target, 30f, 30f);

        if (phaseCd <= 0 && phase < 2) { phase++; phaseCd = 20*60*(3-phase); }

        if (phase == 2) {
            Vec3d dir = target.getPos().subtract(getPos()).normalize();
            setVelocity(dir.x*0.38, getVelocity().y, dir.z*0.38);
            if (laughCd <= 0 && dist < 18) {
                playSound(ModSounds.MIRROR_LAUGH, 1.2f, 0.7f+random.nextFloat()*0.3f);
                laughCd = 35;
            }
        } else {
            if (chasing && chaseTicks > 0) {
                Vec3d dir = target.getPos().subtract(getPos()).normalize();
                setVelocity(dir.x*(phase==1?0.32:0.22), getVelocity().y, dir.z*(phase==1?0.32:0.22));
            } else if (chasing && chaseTicks <= 0) {
                chasing = false; setVelocity(0, getVelocity().y, 0);
            }
            int interval = phase==1 ? 90 : 180;
            if (!chasing && mimicTimer%(interval+random.nextInt(80))==0 && dist>8) {
                chasing = true; chaseTicks = 25+random.nextInt(25);
                playSound(ModSounds.MIRROR_LAUGH, 0.7f, 1.1f);
            }
        }

        if (dist < 14 && laughCd <= 0) {
            playSound(ModSounds.MIRROR_LAUGH, 0.9f, 0.85f+random.nextFloat()*0.3f);
            laughCd = 55;
        }

        if (dist < 2.8 && getWorld().getTime()%20==0) {
            target.damage(target.getDamageSources().generic(), 12f);
            if (target instanceof ServerPlayerEntity sp) {
                sp.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 60, 1));
                sp.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 40, 0));
            }
            playSound(ModSounds.MIRROR_MIMIC, 1.3f, 0.5f);
        }

        if (mimicTimer%280==0 && dist<35 && target instanceof ServerPlayerEntity sp) {
            String name = targetName.isEmpty() ? target.getName().getString() : targetName;
            sp.networkHandler.sendPacket(new TitleFadeS2CPacket(3, 35, 10));
            sp.networkHandler.sendPacket(new TitleS2CPacket(
                Text.literal(corruptName(name)).formatted(Formatting.DARK_RED)));
            sp.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal("§8izliyorum")));
        }

        if (mimicTimer%420==0 && dist<30 && target instanceof ServerPlayerEntity sp) {
            String name = targetName.isEmpty() ? target.getName().getString() : targetName;
            String[] phrases = {"neden kaciyorsun","ben senin yuzun","bak bana","ha ha ha","dur biraz","nereye"};
            sp.sendMessage(Text.literal("§8"+corruptName(name)+": §4§o"+phrases[random.nextInt(phrases.length)]), false);
        }
    }

    private String corruptName(String name) {
        StringBuilder sb = new StringBuilder();
        for (char c : name.toCharArray())
            sb.append(random.nextFloat()<0.35f ? (char)(c+random.nextInt(3)) : c);
        return sb.toString();
    }

    private PlayerEntity findTarget(ServerWorld sw) {
        if (!targetName.isEmpty())
            for (PlayerEntity p : sw.getPlayers())
                if (p.getName().getString().equals(targetName)) return p;
        PlayerEntity res = null; double best = 70.0;
        for (PlayerEntity p : sw.getPlayers()) {
            if (p.isCreative()||p.isSpectator()) continue;
            double d = distanceTo(p);
            if (d < best) { best = d; res = p; }
        }
        return res;
    }

    @Override public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt); nbt.putString("TargetName", targetName); nbt.putInt("Phase", phase);
    }
    @Override public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt); targetName = nbt.getString("TargetName"); phase = nbt.getInt("Phase");
    }
    @Override public boolean damage(DamageSource s, float a) {
        if (a>0) playSound(ModSounds.MIRROR_LAUGH, 1.2f, 0.4f);
        return super.damage(s, a);
    }
    @Override public void onDeath(DamageSource s) { super.onDeath(s); }
    @Override protected SoundEvent getAmbientSound() { return null; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.MIRROR_LAUGH; }
    @Override protected SoundEvent getDeathSound() { return ModSounds.MIRROR_MIMIC; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean cannotDespawn() { return true; }
}
