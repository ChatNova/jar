package com.darkpresence.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class WarningScreen extends Screen {

    private int ticks  = 0;
    private int waitCd = 120;

    public WarningScreen() { super(Text.literal("")); }

    @Override
    protected void init() {
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Kabul et ve devam et"),
            btn -> close()
        ).dimensions(width/2-120, height-52, 240, 24).build());

        addDrawableChild(ButtonWidget.builder(
            Text.literal("Cikis"),
            btn -> { if (client != null) client.stop(); }
        ).dimensions(width/2-50, height-24, 100, 18).build());
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ticks++;
        waitCd--;

        // tam siyah zemin - nabız efekti YOK (yazıları bozuyor)
        ctx.fill(0, 0, width, height, 0xFF000000);

        // sadece kenar animasyonu - yazılara dokunmuyor
        int pulse = (int)(Math.sin(ticks * 0.05) * 3 + 3);
        ctx.fill(0, 0, width, pulse, 0xFFAA0000);
        ctx.fill(0, height-pulse, width, height, 0xFFAA0000);
        ctx.fill(0, 0, pulse, height, 0xFFAA0000);
        ctx.fill(width-pulse, 0, width, height, 0xFFAA0000);

        int cx = width/2;
        int y  = 30;

        // başlık
        ctx.drawCenteredTextWithShadow(textRenderer,
            Text.literal("! UYARI !"), cx, y, 0xFFDD0000);
        y += 8;
        ctx.fill(cx-150, y+6, cx+150, y+7, 0xFF550000);
        y += 18;

        // metin arka plan kutusu
        ctx.fill(cx-185, y-8, cx+185, y+110, 0xEE050000);

        // BEYAZ METİNLER - gölgeli, net
        drawLine(ctx, cx, y, "Bu mod korku icerigi barindirir.", 0xFFFFFFFF); y += 14;
        drawLine(ctx, cx, y, "Ani sesler ve psikolojik unsurlar bulunur.", 0xFFEEEEEE); y += 14;
        drawLine(ctx, cx, y, "Rahatsiz edici icerik ve gerilim icerir.", 0xFFEEEEEE); y += 20;
        drawLine(ctx, cx, y, "Not: Mod dunya klasorune kucuk bir dosya kaydeder.", 0xFFAAAAAA); y += 14;
        drawLine(ctx, cx, y, "Bunu kabul etmek zorunda degilsiniz.", 0xFFAAAAAA); y += 22;

        ctx.fill(cx-150, y, cx+150, y+1, 0xFF333333); y += 12;

        drawLine(ctx, cx, y, "Devam ederek tum icerikleri kabul etmis sayilirsiniz.", 0xFFFFCC00);

        // geri sayım
        if (waitCd > 0) {
            int secs = waitCd/20+1;
            ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal(secs + " saniye bekle..."), cx, height-66, 0xFF777777);
        }

        // butonlar
        super.render(ctx, mx, my, delta);

        // fade-in
        if (ticks < 20) {
            int alpha = (int)((1.0 - ticks/20.0)*255);
            ctx.fill(0, 0, width, height, (alpha << 24));
        }
    }

    private void drawLine(DrawContext ctx, int cx, int y, String text, int color) {
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(text), cx, y, color);
    }

    @Override
    public void tick() {
        super.tick();
        children().forEach(c -> {
            if (c instanceof ButtonWidget b && b.getMessage().getString().contains("Kabul"))
                b.active = waitCd <= 0;
        });
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause()      { return true;  }
}
