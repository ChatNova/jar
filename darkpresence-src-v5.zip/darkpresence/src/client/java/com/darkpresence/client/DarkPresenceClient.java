package com.darkpresence.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class DarkPresenceClient implements ClientModInitializer {

    private int ticks = 0;
    private boolean shown = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ticks++;
            // 3 saniye bekle sonra uyarı ekranını aç
            if (ticks == 60 && !shown) {
                shown = true;
                client.setScreen(new WarningScreen());
            }
        });
    }
}
