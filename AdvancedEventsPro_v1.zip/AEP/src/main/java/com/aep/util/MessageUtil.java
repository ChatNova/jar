package com.aep.util;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;
import java.time.Duration;
public class MessageUtil {
    private static final LegacyComponentSerializer SER = LegacyComponentSerializer.legacyAmpersand();
    public static Component parse(String msg) { return SER.deserialize(msg); }
    public static void sendTitle(Player p, String title, String sub, int in, int stay, int out) {
        p.showTitle(Title.title(parse(title), parse(sub),
            Title.Times.times(Duration.ofMillis(in*50L), Duration.ofMillis(stay*50L), Duration.ofMillis(out*50L))));
    }
    public static void sendActionBar(Player p, String msg) { p.sendActionBar(parse(msg)); }
}
