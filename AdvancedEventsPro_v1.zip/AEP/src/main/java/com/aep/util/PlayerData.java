package com.aep.util;
import org.bukkit.GameMode;
import org.bukkit.Location;
public class PlayerData {
    private final Location location;
    private final GameMode gameMode;
    public PlayerData(Location location, GameMode gameMode) {
        this.location = location.clone();
        this.gameMode = gameMode;
    }
    public Location getLocation() { return location.clone(); }
    public GameMode getGameMode() { return gameMode; }
}
