package com.aep.arena;

import com.aep.AdvancedEventsPro;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;

public class ArenaManager {

    private final AdvancedEventsPro plugin;
    private final Map<String, Arena> arenas = new LinkedHashMap<>();

    // Temporary storage while admin sets up an arena
    private final Map<String, Location> pendingC1   = new HashMap<>();
    private final Map<String, String>   pendingMode = new HashMap<>();

    public ArenaManager(AdvancedEventsPro plugin) {
        this.plugin = plugin;
        load();
    }

    // ── Load / Save ──────────────────────────────────────────────────────────

    public void load() {
        arenas.clear();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("arenas");
        if (sec == null) return;
        for (String name : sec.getKeys(false)) {
            String path = "arenas." + name;
            World world = Bukkit.getWorld(plugin.getConfig().getString(path + ".world", "world"));
            if (world == null) { plugin.getLogger().warning("[AEP] Arena '" + name + "': world not found."); continue; }
            String   mode    = plugin.getConfig().getString(path + ".mode", "pvp");
            Location c1      = parseLoc(world, plugin.getConfig().getString(path + ".corner1", "0,64,0"));
            Location c2      = parseLoc(world, plugin.getConfig().getString(path + ".corner2", "0,64,0"));
            boolean  enabled = plugin.getConfig().getBoolean(path + ".enabled", true);
            Arena arena = new Arena(name, mode, world, c1, c2, enabled);
            String hillStr = plugin.getConfig().getString(path + ".hill", null);
            if (hillStr != null) arena.setHillLocation(parseLoc(world, hillStr));
            arenas.put(name.toLowerCase(), arena);
        }
        plugin.getLogger().info("[AEP] Loaded " + arenas.size() + " arena(s).");
    }

    public void reload() { plugin.reloadConfig(); load(); }

    private void save(Arena arena) {
        String path = "arenas." + arena.getName().toLowerCase();
        plugin.getConfig().set(path + ".world",   arena.getWorld().getName());
        plugin.getConfig().set(path + ".mode",    arena.getMode());
        plugin.getConfig().set(path + ".corner1", fmt(arena.getCorner1()));
        plugin.getConfig().set(path + ".corner2", fmt(arena.getCorner2()));
        plugin.getConfig().set(path + ".enabled", arena.isEnabled());
        if (arena.hasCustomHill()) plugin.getConfig().set(path + ".hill", fmt(arena.getHillLocation()));
        plugin.saveConfig();
    }

    // ── Setup commands ────────────────────────────────────────────────────────

    public void beginSetup(String name, String mode, Location c1) {
        pendingC1.put(name.toLowerCase(), c1.clone());
        pendingMode.put(name.toLowerCase(), mode.toLowerCase());
    }

    public boolean hasPendingC1(String name) { return pendingC1.containsKey(name.toLowerCase()); }

    /** Finalize arena with corner2. Returns the created Arena, or null if c1 not set. */
    public Arena finishSetup(String name, Location c2) {
        Location c1   = pendingC1.remove(name.toLowerCase());
        String   mode = pendingMode.remove(name.toLowerCase());
        if (c1 == null) return null;
        Arena arena = new Arena(name, mode != null ? mode : "pvp", c2.getWorld(), c1, c2.clone(), true);
        arenas.put(name.toLowerCase(), arena);
        save(arena);
        return arena;
    }

    public void setHill(String name, Location loc) {
        Arena a = arenas.get(name.toLowerCase());
        if (a == null) return;
        a.setHillLocation(loc);
        save(a);
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public Arena get(String name)                 { return arenas.get(name.toLowerCase()); }
    public Collection<Arena> getAll()             { return Collections.unmodifiableCollection(arenas.values()); }
    public List<Arena> getEnabled()               { return arenas.values().stream().filter(Arena::isEnabled).toList(); }

    /** Returns enabled arenas assigned to a specific mode. */
    public List<Arena> getForMode(String mode) {
        String m = mode.toLowerCase();
        return arenas.values().stream()
            .filter(Arena::isEnabled)
            .filter(a -> a.getMode().equals(m))
            .toList();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private Location parseLoc(World w, String s) {
        try {
            String[] p = s.split(",");
            return new Location(w, Double.parseDouble(p[0].trim()), Double.parseDouble(p[1].trim()), Double.parseDouble(p[2].trim()));
        } catch (Exception e) { return w.getSpawnLocation(); }
    }

    private String fmt(Location l) { return String.format("%.3f,%.3f,%.3f", l.getX(), l.getY(), l.getZ()); }
}
