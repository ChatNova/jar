package com.aep.arena;

import org.bukkit.Location;
import org.bukkit.World;

/**
 * A named region tied to one specific game mode.
 * KOTH arenas can optionally have a custom hill point.
 */
public class Arena {
    private final String name;
    private final String mode; // pvp / koth / sumo / tntrun / spleef / bowspleef / oneinthequiver
    private final World world;
    private final Location corner1, corner2, center;
    private Location hillLocation; // KOTH only
    private final int minX, maxX, minY, maxY, minZ, maxZ;
    private boolean enabled;

    public Arena(String name, String mode, World world, Location c1, Location c2, boolean enabled) {
        this.name    = name;
        this.mode    = mode.toLowerCase();
        this.world   = world;
        this.corner1 = c1.clone();
        this.corner2 = c2.clone();
        this.enabled = enabled;
        this.minX = (int) Math.min(c1.getX(), c2.getX());
        this.maxX = (int) Math.max(c1.getX(), c2.getX());
        this.minY = (int) Math.min(c1.getY(), c2.getY());
        this.maxY = (int) Math.max(c1.getY(), c2.getY());
        this.minZ = (int) Math.min(c1.getZ(), c2.getZ());
        this.maxZ = (int) Math.max(c1.getZ(), c2.getZ());
        this.center = new Location(world,
            (c1.getX() + c2.getX()) / 2.0,
            maxY + 1.0,
            (c1.getZ() + c2.getZ()) / 2.0);
    }

    public boolean contains(Location loc) {
        if (!loc.getWorld().equals(world)) return false;
        int x = loc.getBlockX(), y = loc.getBlockY(), z = loc.getBlockZ();
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    /** Returns custom hill point if set, otherwise arena center. Used by KOTH. */
    public Location getHillLocation() {
        return hillLocation != null ? hillLocation.clone() : center.clone();
    }

    public void setHillLocation(Location loc) { this.hillLocation = loc != null ? loc.clone() : null; }
    public boolean hasCustomHill()    { return hillLocation != null; }

    public String getName()           { return name; }
    public String getMode()           { return mode; }
    public World getWorld()           { return world; }
    public Location getCorner1()      { return corner1.clone(); }
    public Location getCorner2()      { return corner2.clone(); }
    public Location getCenter()       { return center.clone(); }
    public boolean isEnabled()        { return enabled; }
    public void setEnabled(boolean e) { this.enabled = e; }
    public int getMinY()              { return minY; }
    public int getMaxY()              { return maxY; }
}
