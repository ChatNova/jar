package com.aep.event.modes;

import com.aep.AdvancedEventsPro;
import com.aep.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.UUID;

/** PvP — Last player alive wins. Death = eliminated. */
public class PvPMode extends EventMode {
    public PvPMode(AdvancedEventsPro plugin) { super(plugin); }
    @Override public String getId()             { return "pvp"; }
    @Override public String getDisplayName()    { return "PvP"; }
    @Override public boolean eliminateOnDeath() { return true; }

    @Override public void start() {
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            teleportToArena(p);
            MessageUtil.sendTitle(p, "&c&lPvP", "&eLast one standing wins!", 5, 60, 10);
        }
    }

    @Override public void tick() {
        for (UUID id : new ArrayList<>(alive)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) MessageUtil.sendActionBar(p, "&c⚔ PvP &8| &7Alive: &f" + getAliveCount());
        }
    }

    @Override public void onEliminate(Player player) {
        Bukkit.broadcast(MessageUtil.parse("&8[&cPvP&8] &c" + player.getName() + " &7was eliminated! &8(" + getAliveCount() + " remaining)"));
        if (getAliveCount() == 1) declareWinner(Bukkit.getPlayer(alive.get(0)));
        else if (getAliveCount() == 0) declareWinner(null);
    }

    @Override public void end() { restoreAll(); }
}
