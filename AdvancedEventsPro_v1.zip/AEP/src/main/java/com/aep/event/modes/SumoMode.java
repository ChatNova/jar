package com.aep.event.modes;

import com.aep.AdvancedEventsPro;
import com.aep.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.UUID;

/**
 * Sumo — Push opponents off the platform. Fall below void-y = eliminated.
 * Resistance V prevents all HP loss; only knockback matters.
 * eliminateOnDeath() = false — tick() handles fall detection.
 */
public class SumoMode extends EventMode implements Listener {

    private final double voidY;
    private boolean active = false;

    public SumoMode(AdvancedEventsPro plugin) {
        super(plugin);
        this.voidY = plugin.getConfig().getDouble("sumo.void-y", 0.0);
    }

    @Override public String getId()             { return "sumo"; }
    @Override public String getDisplayName()    { return "Sumo"; }
    @Override public boolean eliminateOnDeath() { return false; } // fall handled in tick()

    @Override public void start() {
        active = true;
        Bukkit.getPluginManager().registerEvents(this, plugin);
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            teleportToArena(p);
            // Resistance V = immune to damage; knockback still applies
            p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 4, false, false, false));
            giveKit(p);
            MessageUtil.sendTitle(p, "&b&lSUMO", "&ePush players off the platform!", 5, 60, 10);
        }
    }

    private void giveKit(Player p) {
        ItemStack stick = new ItemStack(Material.STICK);
        ItemMeta m = stick.getItemMeta();
        if (m != null) {
            m.setDisplayName("§b§lKnockback Stick");
            m.addEnchant(Enchantment.KNOCKBACK, 5, true);
            stick.setItemMeta(m);
        }
        p.getInventory().setItem(0, stick);
    }

    // Cancel all HP damage between participants — knockback still fires
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!active) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        if (!isParticipant(victim)) return;
        e.setDamage(0.0); // 0 damage but event NOT cancelled → knockback fires
    }

    @Override public void tick() {
        for (UUID id : new ArrayList<>(alive)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            if (p.getLocation().getY() <= voidY) {
                p.teleport(arena.getCenter().add(0, 10, 0));
                eliminate(p);
                continue;
            }
            MessageUtil.sendActionBar(p, "&b[Sumo] &7Push them off! &8| &f" + getAliveCount() + " &7alive");
        }
    }

    @Override public void onEliminate(Player player) {
        player.removePotionEffect(PotionEffectType.RESISTANCE);
        Bukkit.broadcast(MessageUtil.parse("&8[&bSumo&8] &c" + player.getName() + " &7fell off! &8(" + getAliveCount() + " remaining)"));
        if (getAliveCount() == 1) declareWinner(Bukkit.getPlayer(alive.get(0)));
        else if (getAliveCount() == 0) declareWinner(null);
    }

    @Override public void end() {
        active = false;
        org.bukkit.event.HandlerList.unregisterAll(this);
        for (UUID id : getParticipants()) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.removePotionEffect(PotionEffectType.RESISTANCE);
        }
        restoreAll();
    }

    public double getVoidY() { return voidY; }
}
