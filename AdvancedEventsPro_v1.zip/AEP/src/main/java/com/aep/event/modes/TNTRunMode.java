package com.aep.event.modes;

import com.aep.AdvancedEventsPro;
import com.aep.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** TNT Run — Floor crumbles under players' feet. Fall = eliminated. */
public class TNTRunMode extends EventMode {

    private final long blockDelay;
    private final Set<Location> queued = new HashSet<>();

    public TNTRunMode(AdvancedEventsPro plugin) {
        super(plugin);
        this.blockDelay = plugin.getConfig().getLong("tntrun.block-delay", 20L);
    }

    @Override public String getId()             { return "tntrun"; }
    @Override public String getDisplayName()    { return "TNT Run"; }
    @Override public boolean eliminateOnDeath() { return true; }

    @Override public void start() {
        queued.clear();
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            teleportToArena(p);
            MessageUtil.sendTitle(p, "&c&lTNT RUN", "&eKeep moving — don't fall!", 5, 60, 10);
        }
    }

    @Override public void tick() {
        double elimY = arena.getMinY() - 5.0;
        for (UUID id : new ArrayList<>(alive)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            if (p.getLocation().getY() < elimY) { eliminate(p); continue; }
            MessageUtil.sendActionBar(p, "&c[TNT Run] &7Keep running! &8| &f" + getAliveCount() + " &7alive");
            breakBelow(p);
        }
    }

    private void breakBelow(Player player) {
        Location feet = player.getLocation();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                Block b = feet.getWorld().getBlockAt(
                    feet.getBlockX() + dx, feet.getBlockY() - 1, feet.getBlockZ() + dz);
                if (b.getType() == Material.AIR) continue;
                Location key = b.getLocation().clone();
                if (queued.contains(key)) continue;
                queued.add(key);
                Material original = b.getType();
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (b.getType() == original) b.setType(Material.AIR);
                    queued.remove(key);
                }, blockDelay);
            }
        }
    }

    @Override public void onEliminate(Player player) {
        Bukkit.broadcast(MessageUtil.parse("&8[&cTNT Run&8] &c" + player.getName() + " &7fell! &8(" + getAliveCount() + " remaining)"));
        if (getAliveCount() == 1) declareWinner(Bukkit.getPlayer(alive.get(0)));
        else if (getAliveCount() == 0) declareWinner(null);
    }

    @Override public void end() { queued.clear(); restoreAll(); }
}
