package com.aep.event.modes;

import com.aep.AdvancedEventsPro;
import com.aep.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * King of the Hill — Stand in the hill zone alone.
 * Hill = arena.getHillLocation() (custom point or arena center).
 * Contested = capture pauses. Capturer killed = progress resets.
 */
public class KOTHMode extends EventMode {
    private UUID capturingPlayer = null;
    private int  captureTime     = 0;
    private final int requiredTime;
    private final int hillRadius;

    public KOTHMode(AdvancedEventsPro plugin) {
        super(plugin);
        this.requiredTime = plugin.getConfig().getInt("koth.capture-time", 60);
        this.hillRadius   = plugin.getConfig().getInt("koth.hill-radius", 3);
    }

    @Override public String getId()             { return "koth"; }
    @Override public String getDisplayName()    { return "King of the Hill"; }
    @Override public boolean eliminateOnDeath() { return true; }

    @Override public void start() {
        capturingPlayer = null; captureTime = 0;
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            teleportToArena(p);
            MessageUtil.sendTitle(p, "&6&lKOTH", "&eHold the hill for &6" + requiredTime + "s!", 5, 60, 10);
        }
    }

    @Override public void tick() {
        Location hill = arena.getHillLocation();
        double hx = hill.getX(), hz = hill.getZ();
        int minY = arena.getMinY(), maxY = arena.getMaxY() + 5;

        UUID onHill = null; int contested = 0;
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            Location l = p.getLocation();
            if (l.getWorld() == null || !l.getWorld().equals(hill.getWorld())) continue;
            if (Math.abs(l.getX() - hx) <= hillRadius
             && Math.abs(l.getZ() - hz) <= hillRadius
             && l.getBlockY() >= minY && l.getBlockY() <= maxY) {
                contested++; if (onHill == null) onHill = id;
            }
        }

        String bar;
        if (onHill != null && contested == 1) {
            if (!onHill.equals(capturingPlayer)) { capturingPlayer = onHill; captureTime = 0; }
            captureTime++;
            Player cap = Bukkit.getPlayer(capturingPlayer);
            if (cap == null) { capturingPlayer = null; return; }
            bar = "&6[KOTH] &a" + cap.getName() + " &7holding: &e" + captureTime + "&8/&6" + requiredTime + "s &8| &f" + getAliveCount() + " &7alive";
            if (captureTime >= requiredTime) { declareWinner(cap); return; }
        } else if (contested > 1) {
            bar = "&6[KOTH] &cContested! &7Stand alone to capture! &8| &f" + getAliveCount() + " &7alive";
        } else {
            if (captureTime > 0) captureTime = Math.max(0, captureTime - 1);
            bar = "&6[KOTH] &7Capture the hill! &8| &f" + getAliveCount() + " &7alive";
        }
        for (UUID id : alive) { Player p = Bukkit.getPlayer(id); if (p != null) MessageUtil.sendActionBar(p, bar); }
    }

    @Override public void onEliminate(Player player) {
        if (player.getUniqueId().equals(capturingPlayer)) { capturingPlayer = null; captureTime = 0; }
        Bukkit.broadcast(MessageUtil.parse("&8[&6KOTH&8] &c" + player.getName() + " &7was eliminated! &8(" + getAliveCount() + " remaining)"));
        if (getAliveCount() == 1) declareWinner(Bukkit.getPlayer(alive.get(0)));
        else if (getAliveCount() == 0) declareWinner(null);
    }

    @Override public void end() { restoreAll(); }
}
