package com.aep.event.modes;

import com.aep.AdvancedEventsPro;
import com.aep.arena.Arena;
import com.aep.util.MessageUtil;
import com.aep.util.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

import java.util.*;

public abstract class EventMode {

    protected final AdvancedEventsPro plugin;
    protected Arena arena;

    private final Map<UUID, PlayerData> savedData = new HashMap<>();
    protected final List<UUID> participants = new ArrayList<>();
    protected final List<UUID> alive        = new ArrayList<>();

    public EventMode(AdvancedEventsPro plugin) { this.plugin = plugin; }

    // Called by EventInstance before start()
    public void setup(Arena arena, List<Player> players, Map<UUID, PlayerData> preData) {
        this.arena = arena;
        savedData.clear(); participants.clear(); alive.clear();
        for (Player p : players) {
            UUID id = p.getUniqueId();
            savedData.put(id, preData.getOrDefault(id, new PlayerData(p.getLocation(), p.getGameMode())));
            participants.add(id);
            alive.add(id);
        }
    }

    // ── Abstract ──────────────────────────────────────────────────────────────
    public abstract String getId();
    public abstract String getDisplayName();
    public abstract void start();
    public abstract void tick();
    public abstract void onEliminate(Player player);
    public abstract void end();

    /**
     * Return false if deaths should NOT eliminate the player (e.g. OITQ, Sumo).
     * The global EventListener checks this before calling eliminate().
     */
    public boolean eliminateOnDeath() { return true; }

    // ── Shared helpers ────────────────────────────────────────────────────────

    protected void teleportToArena(Player p) {
        p.teleport(arena.getCenter());
        p.setGameMode(GameMode.SURVIVAL);
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setSaturation(20);
        p.getInventory().clear();
    }

    private void restorePlayer(Player p) {
        PlayerData d = savedData.get(p.getUniqueId());
        if (d == null) return;
        p.getInventory().clear();
        p.setGameMode(d.getGameMode());
        p.teleport(d.getLocation());
    }

    protected void restoreAll() {
        for (UUID id : new ArrayList<>(participants)) {
            Player p = org.bukkit.Bukkit.getPlayer(id);
            if (p != null) restorePlayer(p);
        }
        savedData.clear();
    }

    public void eliminate(Player player) {
        if (!alive.contains(player.getUniqueId())) return;
        alive.remove(player.getUniqueId());
        player.setGameMode(GameMode.SPECTATOR);
        MessageUtil.sendTitle(player, "&c&lELIMINATED", "&7Better luck next time!", 5, 40, 10);
        onEliminate(player);
    }

    /** Modes call this to end the event with a winner. */
    protected void declareWinner(Player winner) {
        plugin.getEventManager().declareWinner(winner, getId());
    }

    // ── Getters ───────────────────────────────────────────────────────────────
    public boolean isAlive(Player p)       { return alive.contains(p.getUniqueId()); }
    public boolean isParticipant(Player p) { return participants.contains(p.getUniqueId()); }
    public List<UUID> getAlive()           { return Collections.unmodifiableList(alive); }
    public List<UUID> getParticipants()    { return Collections.unmodifiableList(participants); }
    public Arena getArena()                { return arena; }
    protected int getAliveCount()          { return alive.size(); }
}
