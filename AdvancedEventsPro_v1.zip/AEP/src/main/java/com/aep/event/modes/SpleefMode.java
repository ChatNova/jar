package com.aep.event.modes;

import com.aep.AdvancedEventsPro;
import com.aep.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.UUID;

/** Spleef — Dig the floor under opponents with an Efficiency V shovel. Fall = eliminated. */
public class SpleefMode extends EventMode {
    public SpleefMode(AdvancedEventsPro plugin) { super(plugin); }
    @Override public String getId()             { return "spleef"; }
    @Override public String getDisplayName()    { return "Spleef"; }
    @Override public boolean eliminateOnDeath() { return true; }

    @Override public void start() {
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            teleportToArena(p);
            p.getInventory().setItem(0, shovel());
            MessageUtil.sendTitle(p, "&a&lSPLEEF", "&eDig the floor under your opponents!", 5, 60, 10);
        }
    }

    private ItemStack shovel() {
        ItemStack s = new ItemStack(Material.DIAMOND_SHOVEL);
        ItemMeta m = s.getItemMeta();
        if (m != null) {
            m.setDisplayName("§a§lSpleef Shovel");
            m.addEnchant(Enchantment.EFFICIENCY, 5, true);
            m.addEnchant(Enchantment.UNBREAKING, 10, true);
            s.setItemMeta(m);
        }
        return s;
    }

    @Override public void tick() {
        double elimY = arena.getMinY() - 5.0;
        for (UUID id : new ArrayList<>(alive)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            if (p.getLocation().getY() < elimY) { eliminate(p); continue; }
            MessageUtil.sendActionBar(p, "&a[Spleef] &7Dig under them! &8| &f" + getAliveCount() + " &7alive");
        }
    }

    @Override public void onEliminate(Player player) {
        Bukkit.broadcast(MessageUtil.parse("&8[&aSpleef&8] &c" + player.getName() + " &7fell! &8(" + getAliveCount() + " remaining)"));
        if (getAliveCount() == 1) declareWinner(Bukkit.getPlayer(alive.get(0)));
        else if (getAliveCount() == 0) declareWinner(null);
    }

    @Override public void end() { restoreAll(); }
}
