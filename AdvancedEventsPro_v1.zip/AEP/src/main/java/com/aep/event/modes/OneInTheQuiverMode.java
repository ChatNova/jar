package com.aep.event.modes;

import com.aep.AdvancedEventsPro;
import com.aep.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

/**
 * One in the Quiver — Kill-scoring mode. Dying = respawn, NOT elimination.
 * First to killsToWin bow kills wins the round.
 * eliminateOnDeath() = false — this mode manages its own death/respawn.
 */
public class OneInTheQuiverMode extends EventMode implements Listener {

    private final Map<UUID, Integer> kills = new HashMap<>();
    private final int killsToWin;
    private boolean active = false;

    public OneInTheQuiverMode(AdvancedEventsPro plugin) {
        super(plugin);
        this.killsToWin = plugin.getConfig().getInt("oneinthequiver.kills-to-win", 5);
    }

    @Override public String getId()             { return "oneinthequiver"; }
    @Override public String getDisplayName()    { return "One in the Quiver"; }
    @Override public boolean eliminateOnDeath() { return false; } // respawn, don't eliminate

    @Override public void start() {
        active = true;
        kills.clear();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        for (UUID id : participants) {
            kills.put(id, 0);
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            teleportToArena(p);
            giveKit(p);
            MessageUtil.sendTitle(p, "&d&lONE IN THE QUIVER", "&eFirst to &6" + killsToWin + " &ebow kills wins!", 5, 70, 10);
        }
    }

    private void giveKit(Player p) {
        p.getInventory().clear();
        ItemStack bow = new ItemStack(Material.BOW);
        ItemMeta bm = bow.getItemMeta();
        if (bm != null) {
            bm.setDisplayName("§d§lQuiver Bow");
            bm.addEnchant(Enchantment.POWER, 5, true);
            bm.addEnchant(Enchantment.PUNCH, 1, true);
            bow.setItemMeta(bm);
        }
        ItemStack sword = new ItemStack(Material.IRON_SWORD);
        ItemMeta sm = sword.getItemMeta();
        if (sm != null) { sm.setDisplayName("§7Backup Sword"); sword.setItemMeta(sm); }
        p.getInventory().setItem(0, bow);
        p.getInventory().setItem(1, sword);
        p.getInventory().setItem(9, new ItemStack(Material.ARROW, 1));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        if (!active) return;
        Player victim = event.getEntity();
        if (!isParticipant(victim)) return;

        event.setDeathMessage(null);
        event.getDrops().clear();
        event.setDroppedExp(0);
        event.setKeepInventory(true);

        // Check if killed by an arrow from another participant
        if (victim.getLastDamageCause() instanceof EntityDamageByEntityEvent dmg
            && dmg.getDamager() instanceof Arrow arrow
            && arrow.getShooter() instanceof Player shooter
            && isParticipant(shooter)
            && !shooter.getUniqueId().equals(victim.getUniqueId())) {

            kills.merge(shooter.getUniqueId(), 1, Integer::sum);
            int k = kills.get(shooter.getUniqueId());

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!active || !isParticipant(shooter)) return;
                shooter.getInventory().remove(Material.ARROW);
                shooter.getInventory().setItem(9, new ItemStack(Material.ARROW, 1));
                MessageUtil.sendActionBar(shooter, "&d+1 Kill! &8(" + k + "/" + killsToWin + ") &aArrow refilled!");
            }, 5L);

            Bukkit.broadcast(MessageUtil.parse(
                "&8[&dOITQ&8] &e" + shooter.getName() + " &7shot &c" + victim.getName() + "! &8(" + k + "/" + killsToWin + " kills)"));

            if (k >= killsToWin) { declareWinner(shooter); return; }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent event) {
        if (!active) return;
        Player player = event.getPlayer();
        if (!isParticipant(player)) return;
        event.setRespawnLocation(arena.getCenter());
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!active || !isParticipant(player)) return;
            player.setGameMode(GameMode.SURVIVAL);
            player.setHealth(player.getMaxHealth());
            player.setFoodLevel(20);
            giveKit(player);
            MessageUtil.sendTitle(player, "&eRESPAWNED", "&7Get back in the fight!", 3, 25, 5);
        }, 2L);
    }

    @Override public void tick() {
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            int k = kills.getOrDefault(id, 0);
            MessageUtil.sendActionBar(p, "&d[OITQ] &7Kills: &f" + k + "/" + killsToWin + " &8| &f" + getAliveCount() + " &7players");
        }
    }

    @Override public void onEliminate(Player player) {
        // Only called via forceStop
        Bukkit.broadcast(MessageUtil.parse("&8[&dOITQ&8] &c" + player.getName() + " &7was removed."));
        if (getAliveCount() == 1) declareWinner(Bukkit.getPlayer(alive.get(0)));
        else if (getAliveCount() == 0) declareWinner(null);
    }

    @Override public void end() {
        active = false;
        kills.clear();
        org.bukkit.event.HandlerList.unregisterAll(this);
        restoreAll();
    }
}
