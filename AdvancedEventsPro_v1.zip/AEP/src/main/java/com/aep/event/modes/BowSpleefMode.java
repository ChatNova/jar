package com.aep.event.modes;

import com.aep.AdvancedEventsPro;
import com.aep.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.UUID;

/** Bow Spleef — Shoot arrows to break blocks under enemies. Fall = eliminated. */
public class BowSpleefMode extends EventMode implements Listener {

    private boolean active = false;

    public BowSpleefMode(AdvancedEventsPro plugin) { super(plugin); }
    @Override public String getId()             { return "bowspleef"; }
    @Override public String getDisplayName()    { return "Bow Spleef"; }
    @Override public boolean eliminateOnDeath() { return true; }

    @Override public void start() {
        active = true;
        Bukkit.getPluginManager().registerEvents(this, plugin);
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            teleportToArena(p);
            p.getInventory().setItem(0, bow());
            p.getInventory().setItem(9, new ItemStack(Material.ARROW, 1)); // Infinity needs 1 arrow
            MessageUtil.sendTitle(p, "&e&lBOW SPLEEF", "&eShoot arrows to break the floor!", 5, 60, 10);
        }
    }

    private ItemStack bow() {
        ItemStack b = new ItemStack(Material.BOW);
        ItemMeta m = b.getItemMeta();
        if (m != null) {
            m.setDisplayName("§e§lSpleef Bow");
            m.addEnchant(Enchantment.INFINITY, 1, true);
            m.addEnchant(Enchantment.POWER, 2, true);
            b.setItemMeta(m);
        }
        return b;
    }

    @EventHandler
    public void onArrowHit(ProjectileHitEvent event) {
        if (!active) return;
        if (!(event.getEntity() instanceof Arrow arrow)) return;
        if (!(arrow.getShooter() instanceof Player shooter)) { arrow.remove(); return; }
        if (!isParticipant(shooter)) { arrow.remove(); return; }
        Block hit = event.getHitBlock();
        if (hit != null && hit.getType() != Material.AIR) hit.setType(Material.AIR);
        arrow.remove();
    }

    @Override public void tick() {
        double elimY = arena.getMinY() - 5.0;
        for (UUID id : new ArrayList<>(alive)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            if (p.getLocation().getY() < elimY) { eliminate(p); continue; }
            MessageUtil.sendActionBar(p, "&e[Bow Spleef] &7Shoot under enemies! &8| &f" + getAliveCount() + " &7alive");
        }
    }

    @Override public void onEliminate(Player player) {
        Bukkit.broadcast(MessageUtil.parse("&8[&eBow Spleef&8] &c" + player.getName() + " &7fell! &8(" + getAliveCount() + " remaining)"));
        if (getAliveCount() == 1) declareWinner(Bukkit.getPlayer(alive.get(0)));
        else if (getAliveCount() == 0) declareWinner(null);
    }

    @Override public void end() {
        active = false;
        org.bukkit.event.HandlerList.unregisterAll(this);
        restoreAll();
    }
}
