package com.aep.event;

import com.aep.AdvancedEventsPro;
import com.aep.arena.Arena;
import com.aep.event.modes.EventMode;
import com.aep.util.MessageUtil;
import com.aep.util.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * One active event for one specific mode.
 * Multiple instances can run simultaneously (one per mode).
 * Players join with: /event join <modeId>
 */
public class EventInstance {

    private final AdvancedEventsPro plugin;
    private final String     modeId;
    private final EventMode  mode;
    private final Arena      arena;

    private EventState state = EventState.IDLE;

    private final List<UUID>            waiting     = new ArrayList<>();
    private final Map<UUID, PlayerData> waitingData = new HashMap<>();

    private BukkitTask countdownTask = null;
    private BukkitTask tickTask      = null;
    private int        joinCountdown = 0;

    public EventInstance(AdvancedEventsPro plugin, String modeId, EventMode mode, Arena arena) {
        this.plugin  = plugin;
        this.modeId  = modeId;
        this.mode    = mode;
        this.arena   = arena;
    }

    // ── Announce join phase ───────────────────────────────────────────────────

    public void announceJoin() {
        state = EventState.WAITING;
        waiting.clear();
        waitingData.clear();
        joinCountdown = plugin.getConfig().getInt("events.join-duration", 120);

        // Mode-specific announcement from config, or default
        String defaultMsg = "&6&l[EVENT] &e" + mode.getDisplayName()
            + " &7is starting at &a" + arena.getName()
            + "&7! Join with &b/event join " + modeId + "&7!";
        String msg = plugin.getConfig()
            .getString("messages.announce-" + modeId, defaultMsg)
            .replace("{mode}",  mode.getDisplayName())
            .replace("{arena}", arena.getName());

        Bukkit.broadcast(MessageUtil.parse(msg));
        plugin.getDiscordWebhook().send(
            "🎮 **" + mode.getDisplayName() + "** at **" + arena.getName()
            + "** — `/event join " + modeId + "`");

        // Countdown: chat only at 60/30/10s, actionbar every second
        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != EventState.WAITING) { stopCountdown(); return; }
            joinCountdown--;

            if (joinCountdown == 60 || joinCountdown == 30 || joinCountdown == 10) {
                Bukkit.broadcast(MessageUtil.parse(
                    "&6[Event] &e" + mode.getDisplayName() + " &7in &6" + joinCountdown
                    + "s &8| &a/event join " + modeId + " &8(&f" + waiting.size() + " &7joined)"));
            }

            String bar = "&6[Event] &e" + mode.getDisplayName()
                + " &7in &6" + joinCountdown + "s &8| &a/event join " + modeId
                + " &8(&f" + waiting.size() + ")";
            Bukkit.getOnlinePlayers().forEach(p -> MessageUtil.sendActionBar(p, bar));

            if (joinCountdown <= 0) { stopCountdown(); startEvent(); }
        }, 20L, 20L);
    }

    // ── Join / Leave ──────────────────────────────────────────────────────────

    public boolean join(Player player) {
        if (state != EventState.WAITING) {
            player.sendMessage(MessageUtil.parse("&c" + mode.getDisplayName() + " &cis not accepting players right now."));
            return false;
        }
        if (waiting.contains(player.getUniqueId())) {
            player.sendMessage(MessageUtil.parse("&cYou already joined &e" + mode.getDisplayName() + "&c!"));
            return false;
        }
        waitingData.put(player.getUniqueId(), new PlayerData(player.getLocation(), player.getGameMode()));
        waiting.add(player.getUniqueId());
        player.sendMessage(MessageUtil.parse(
            plugin.getConfig().getString("messages.join-success",
                "&aYou joined &e{mode}&a! Players waiting: &f{count}")
            .replace("{mode}",  mode.getDisplayName())
            .replace("{count}", String.valueOf(waiting.size()))));
        return true;
    }

    public boolean leave(Player player) {
        UUID id = player.getUniqueId();
        if (state == EventState.WAITING && waiting.contains(id)) {
            waiting.remove(id);
            PlayerData d = waitingData.remove(id);
            if (d != null) { player.setGameMode(d.getGameMode()); player.teleport(d.getLocation()); }
            player.sendMessage(MessageUtil.parse(plugin.getConfig().getString("messages.leave-success", "&eYou left the event.")));
            return true;
        }
        if (state == EventState.RUNNING && mode.isParticipant(player)) {
            mode.eliminate(player);
            player.sendMessage(MessageUtil.parse(plugin.getConfig().getString("messages.leave-success", "&eYou left the event.")));
            return true;
        }
        return false;
    }

    public boolean involves(Player p) {
        return waiting.contains(p.getUniqueId()) || (mode != null && mode.isParticipant(p));
    }

    // ── Start event ───────────────────────────────────────────────────────────

    private void startEvent() {
        if (state != EventState.WAITING) return;
        waiting.removeIf(id -> Bukkit.getPlayer(id) == null);
        waitingData.keySet().retainAll(new HashSet<>(waiting));

        int min = plugin.getConfig().getInt(modeId + ".min-players", 2);
        if (waiting.size() < min) {
            Bukkit.broadcast(MessageUtil.parse(
                plugin.getConfig().getString("messages.event-cancelled",
                    "&c[Event] &e{mode} &ccancelled — not enough players. &8({count}/{min})")
                .replace("{mode}",  mode.getDisplayName())
                .replace("{count}", String.valueOf(waiting.size()))
                .replace("{min}",   String.valueOf(min))));
            restoreWaiting();
            finish();
            return;
        }

        List<Player> players = new ArrayList<>();
        for (UUID id : waiting) { Player p = Bukkit.getPlayer(id); if (p != null) players.add(p); }

        state = EventState.RUNNING;
        mode.setup(arena, players, new HashMap<>(waitingData));
        mode.start();

        tickTask = Bukkit.getScheduler().runTaskTimer(plugin,
            () -> { if (state == EventState.RUNNING) mode.tick(); }, 20L, 20L);
    }

    // ── Declare winner ────────────────────────────────────────────────────────

    public void declareWinner(Player winner) {
        if (state != EventState.RUNNING) return;
        if (tickTask != null) { tickTask.cancel(); tickTask = null; }

        if (winner != null) {
            Bukkit.broadcast(MessageUtil.parse(
                plugin.getConfig().getString("messages.winner-broadcast",
                    "&6&l[EVENT] &e{player} &6won &e{mode}&6!")
                .replace("{player}", winner.getName())
                .replace("{mode}",   mode.getDisplayName())));
            MessageUtil.sendTitle(winner, "&6&lWINNER!", "&eCongratulations, " + winner.getName() + "!", 10, 80, 20);
            plugin.getRewardManager().giveRewards(winner);
            plugin.getDiscordWebhook().send("🏆 **" + winner.getName() + "** won **" + mode.getDisplayName() + "**!");
        } else {
            Bukkit.broadcast(MessageUtil.parse("&6[Event] &7" + mode.getDisplayName() + " ended with no winner."));
        }

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            mode.end();
            finish();
        }, 100L);
    }

    public void forceStop(String adminName) {
        stopCountdown();
        if (tickTask != null) { tickTask.cancel(); tickTask = null; }
        Bukkit.broadcast(MessageUtil.parse("&c[Event] &e" + mode.getDisplayName() + " &cstopped by &f" + adminName + "&c."));
        restoreWaiting();
        if (state == EventState.RUNNING) mode.end();
        finish();
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    private void restoreWaiting() {
        for (UUID id : new ArrayList<>(waiting)) {
            Player p = Bukkit.getPlayer(id);
            PlayerData d = waitingData.get(id);
            if (p != null && d != null) { p.setGameMode(d.getGameMode()); p.teleport(d.getLocation()); }
        }
    }

    private void stopCountdown() {
        if (countdownTask != null) { countdownTask.cancel(); countdownTask = null; }
    }

    private void finish() {
        state = EventState.IDLE;
        waiting.clear();
        waitingData.clear();
        joinCountdown = 0;
        plugin.getEventManager().onInstanceFinished(modeId);
    }

    // ── Getters ───────────────────────────────────────────────────────────────
    public EventState getState()          { return state; }
    public EventMode  getMode()           { return mode; }
    public Arena      getArena()          { return arena; }
    public String     getModeId()         { return modeId; }
    public List<UUID> getWaiting()        { return Collections.unmodifiableList(waiting); }
    public int        getJoinCountdown()  { return joinCountdown; }
    public boolean    isAlive(Player p)   { return mode.isAlive(p); }
}
