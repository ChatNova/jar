package com.aep.event;
public enum EventState { IDLE, WAITING, RUNNING }
