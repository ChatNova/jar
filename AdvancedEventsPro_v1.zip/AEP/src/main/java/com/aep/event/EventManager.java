package com.aep.event;

import com.aep.AdvancedEventsPro;
import com.aep.arena.Arena;
import com.aep.event.modes.*;
import com.aep.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Manages multiple simultaneous EventInstances — one per mode.
 * PvP and KOTH can both be active at the same time, in different arenas.
 */
public class EventManager {

    private final AdvancedEventsPro plugin;

    // Active instances keyed by modeId
    private final Map<String, EventInstance> instances = new LinkedHashMap<>();

    private BukkitTask autoTask          = null;
    private int        autoRotationIndex = 0;

    private static final List<String> ALL_MODES = List.of(
        "pvp", "koth", "sumo", "tntrun", "spleef", "bowspleef", "oneinthequiver");

    public EventManager(AdvancedEventsPro plugin) { this.plugin = plugin; }

    // ── Auto timer ────────────────────────────────────────────────────────────

    public void startAutoTimer() {
        if (autoTask != null) { autoTask.cancel(); autoTask = null; }
        long ticks = plugin.getConfig().getLong("events.auto-interval", 10L) * 60L * 20L;
        autoTask = Bukkit.getScheduler().runTaskTimer(plugin, this::announceNextAuto, ticks, ticks);
        plugin.getLogger().info("[AEP] Auto timer active. Interval: " + (ticks / 20 / 60) + " min.");
    }

    public void stopAutoTimer() {
        if (autoTask != null) { autoTask.cancel(); autoTask = null; }
    }

    /** Called by EventInstance when it finishes (winner declared / cancelled / stopped). */
    public void onInstanceFinished(String modeId) {
        instances.remove(modeId);
    }

    // ── Announce ──────────────────────────────────────────────────────────────

    private void announceNextAuto() {
        List<String> rotation = plugin.getConfig().getStringList("events.rotation");
        if (rotation.isEmpty()) rotation = new ArrayList<>(ALL_MODES);
        // Try each mode in turn until one successfully starts
        for (int i = 0; i < rotation.size(); i++) {
            String id = rotation.get(autoRotationIndex % rotation.size());
            autoRotationIndex++;
            if (announceJoin(id)) return;
        }
    }

    /**
     * Announce a join phase for the given mode.
     * Returns false if that mode is already active or has no configured arena.
     */
    public boolean announceJoin(String modeId) {
        modeId = modeId.toLowerCase();
        if (instances.containsKey(modeId)) return false; // already running

        List<Arena> arenas = plugin.getArenaManager().getForMode(modeId);
        if (arenas.isEmpty()) {
            plugin.getLogger().warning("[AEP] No arena for mode '" + modeId + "'. Add one with /event setarena.");
            return false;
        }

        Arena      arena    = arenas.get(new Random().nextInt(arenas.size()));
        EventMode  mode     = buildMode(modeId);
        EventInstance inst  = new EventInstance(plugin, modeId, mode, arena);
        instances.put(modeId, inst);
        inst.announceJoin();
        return true;
    }

    // ── Join / Leave ──────────────────────────────────────────────────────────

    /**
     * Player joins a specific mode.
     * /event join pvp  /event join koth  etc.
     */
    public boolean join(Player player, String modeId) {
        modeId = modeId.toLowerCase();

        // Already in any event?
        for (EventInstance inst : instances.values()) {
            if (inst.involves(player)) {
                player.sendMessage(MessageUtil.parse(
                    "&cYou are already in &e" + inst.getMode().getDisplayName()
                    + "&c! Use &f/event leave &cfirst."));
                return false;
            }
        }

        EventInstance inst = instances.get(modeId);
        if (inst == null || inst.getState() != EventState.WAITING) {
            // Show all open events
            List<EventInstance> open = instances.values().stream()
                .filter(i -> i.getState() == EventState.WAITING).toList();
            if (open.isEmpty()) {
                player.sendMessage(MessageUtil.parse("&cNo events are currently open. Wait for an announcement!"));
            } else {
                player.sendMessage(MessageUtil.parse("&cNo &e" + modeId + " &cevent is open. Open events:"));
                for (EventInstance o : open) {
                    player.sendMessage(MessageUtil.parse(
                        "  &8» &a/event join " + o.getModeId()
                        + " &8— &e" + o.getMode().getDisplayName()
                        + " &8(" + o.getWaiting().size() + " waiting, " + o.getJoinCountdown() + "s left)"));
                }
            }
            return false;
        }

        return inst.join(player);
    }

    public boolean leave(Player player) {
        for (EventInstance inst : instances.values()) {
            if (inst.involves(player)) return inst.leave(player);
        }
        return false;
    }

    // ── Winner (called by EventMode via EventInstance) ────────────────────────

    public void declareWinner(Player winner, String modeId) {
        EventInstance inst = instances.get(modeId.toLowerCase());
        if (inst != null) inst.declareWinner(winner);
    }

    // ── Admin controls ────────────────────────────────────────────────────────

    public void forceStop(String modeId, String adminName) {
        EventInstance inst = instances.get(modeId.toLowerCase());
        if (inst != null) inst.forceStop(adminName);
        else plugin.getLogger().info("[AEP] No active event for: " + modeId);
    }

    public void forceStopAll(String adminName) {
        for (String id : new ArrayList<>(instances.keySet())) forceStop(id, adminName);
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public Map<String, EventInstance> getInstances()    { return Collections.unmodifiableMap(instances); }
    public EventInstance getInstance(String modeId)     { return instances.get(modeId.toLowerCase()); }
    public boolean hasActive(String modeId)             { return instances.containsKey(modeId.toLowerCase()); }
    public boolean hasAnyActive()                       { return !instances.isEmpty(); }

    public EventInstance getPlayerInstance(Player p) {
        for (EventInstance inst : instances.values()) if (inst.involves(p)) return inst;
        return null;
    }

    public boolean isInEvent(Player p) { return getPlayerInstance(p) != null; }

    public boolean isAlive(Player p) {
        EventInstance inst = getPlayerInstance(p);
        return inst != null && inst.isAlive(p);
    }

    // ── Mode factory ──────────────────────────────────────────────────────────

    private EventMode buildMode(String id) {
        return switch (id) {
            case "koth"           -> new KOTHMode(plugin);
            case "sumo"           -> new SumoMode(plugin);
            case "tntrun"         -> new TNTRunMode(plugin);
            case "spleef"         -> new SpleefMode(plugin);
            case "bowspleef"      -> new BowSpleefMode(plugin);
            case "oneinthequiver" -> new OneInTheQuiverMode(plugin);
            default               -> new PvPMode(plugin);
        };
    }
}
