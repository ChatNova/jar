package com.aep.reward;

import com.aep.AdvancedEventsPro;
import com.aep.util.MessageUtil;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.RegisteredServiceProvider;

public class RewardManager {

    private final AdvancedEventsPro plugin;
    private Economy economy = null;

    public RewardManager(AdvancedEventsPro plugin) {
        this.plugin = plugin;
        if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
            if (rsp != null) economy = rsp.getProvider();
        }
    }

    public void giveRewards(Player winner) {
        double money = plugin.getConfig().getDouble("rewards.money", 0);
        if (money > 0 && economy != null) {
            economy.depositPlayer(winner, money);
            winner.sendMessage(MessageUtil.parse("&a+$" + (int) money + " reward!"));
        }
        for (String s : plugin.getConfig().getStringList("rewards.items")) {
            try {
                String[] p = s.split(":");
                winner.getInventory().addItem(new ItemStack(Material.valueOf(p[0].toUpperCase()), Integer.parseInt(p[1])));
            } catch (Exception ignored) {}
        }
        for (String cmd : plugin.getConfig().getStringList("rewards.commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", winner.getName()));
        }
    }
}
