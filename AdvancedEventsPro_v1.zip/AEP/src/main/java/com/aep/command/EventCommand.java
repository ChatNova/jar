package com.aep.command;

import com.aep.AdvancedEventsPro;
import com.aep.arena.Arena;
import com.aep.event.EventInstance;
import com.aep.event.EventState;
import com.aep.util.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class EventCommand implements CommandExecutor, TabCompleter {

    private static final List<String> MODES = List.of(
        "pvp", "koth", "sumo", "tntrun", "spleef", "bowspleef", "oneinthequiver");

    private final AdvancedEventsPro plugin;

    public EventCommand(AdvancedEventsPro plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) { help(sender); return true; }

        switch (args[0].toLowerCase()) {

            // ── Player commands ───────────────────────────────────────────────

            case "join" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
                if (!p.hasPermission("aep.join")) { p.sendMessage(MessageUtil.parse("&cNo permission.")); return true; }
                if (args.length < 2) {
                    // Show open events
                    List<EventInstance> open = plugin.getEventManager().getInstances().values().stream()
                        .filter(i -> i.getState() == EventState.WAITING).toList();
                    if (open.isEmpty()) {
                        p.sendMessage(MessageUtil.parse("&cNo events are open right now. Wait for an announcement!"));
                    } else {
                        p.sendMessage(MessageUtil.parse("&6Open events:"));
                        for (EventInstance i : open)
                            p.sendMessage(MessageUtil.parse("  &8» &a/event join " + i.getModeId()
                                + " &8— &e" + i.getMode().getDisplayName()
                                + " &8(" + i.getWaiting().size() + " waiting, " + i.getJoinCountdown() + "s)"));
                    }
                } else {
                    plugin.getEventManager().join(p, args[1]);
                }
            }

            case "leave" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
                if (!plugin.getEventManager().leave(p))
                    p.sendMessage(MessageUtil.parse("&cYou are not in an event."));
            }

            case "list" -> {
                sender.sendMessage(MessageUtil.parse("&6&l=== AdvancedEventsPro ==="));
                // Arenas
                if (plugin.getArenaManager().getAll().isEmpty()) {
                    sender.sendMessage(MessageUtil.parse("&7No arenas. Use &f/event setarena <name> <mode> corner1"));
                } else {
                    for (Arena a : plugin.getArenaManager().getAll()) {
                        sender.sendMessage(MessageUtil.parse(
                            "  &8» &7Arena &e" + a.getName() + " &8[&6" + a.getMode() + "&8] "
                            + (a.isEnabled() ? "&aEnabled" : "&cDisabled")
                            + (a.hasCustomHill() ? " &8| &6Hill✓" : "")));
                    }
                }
                // Active events
                if (plugin.getEventManager().getInstances().isEmpty()) {
                    sender.sendMessage(MessageUtil.parse("&7No active events."));
                } else {
                    sender.sendMessage(MessageUtil.parse("&7Active events:"));
                    for (EventInstance inst : plugin.getEventManager().getInstances().values()) {
                        String stateStr = inst.getState() == EventState.RUNNING ? "&cRunning"
                            : inst.getState() == EventState.WAITING ? "&eWaiting " + inst.getJoinCountdown() + "s" : "&7Idle";
                        sender.sendMessage(MessageUtil.parse(
                            "  &8» &e" + inst.getMode().getDisplayName()
                            + " &8@ &f" + inst.getArena().getName() + " &8— " + stateStr));
                    }
                }
            }

            case "learn" -> new LearnCommand(plugin).show(sender, args.length > 1 ? args[1] : "");

            // ── Admin commands ────────────────────────────────────────────────

            case "start" -> {
                if (!sender.hasPermission("aep.admin")) { sender.sendMessage(MessageUtil.parse("&cNo permission.")); return true; }
                if (args.length < 2) { sender.sendMessage(MessageUtil.parse("&cUsage: /event start <mode>")); return true; }
                boolean ok = plugin.getEventManager().announceJoin(args[1]);
                sender.sendMessage(MessageUtil.parse(ok
                    ? "&aAnnounced &e" + args[1] + "&a event!"
                    : "&cFailed. Check that a &e" + args[1] + " &carena exists and the mode isn't already running."));
            }

            case "stop" -> {
                if (!sender.hasPermission("aep.admin")) { sender.sendMessage(MessageUtil.parse("&cNo permission.")); return true; }
                if (args.length < 2) { sender.sendMessage(MessageUtil.parse("&cUsage: /event stop <mode|all>")); return true; }
                if (args[1].equalsIgnoreCase("all")) plugin.getEventManager().forceStopAll(sender.getName());
                else plugin.getEventManager().forceStop(args[1], sender.getName());
            }

            case "admin" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
                if (!p.hasPermission("aep.admin")) { p.sendMessage(MessageUtil.parse("&cNo permission.")); return true; }
                plugin.getAdminGUI().open(p);
            }

            case "setarena" -> {
                // /event setarena <name> <mode> <corner1|corner2>
                // /event setarena <name> sethill
                if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
                if (!p.hasPermission("aep.admin")) { p.sendMessage(MessageUtil.parse("&cNo permission.")); return true; }

                if (args.length == 3 && args[2].equalsIgnoreCase("sethill")) {
                    plugin.getArenaManager().setHill(args[1], p.getLocation());
                    p.sendMessage(MessageUtil.parse("&aHill point set for arena &e" + args[1] + "&a at your location!"));
                    return true;
                }

                if (args.length < 4) {
                    p.sendMessage(MessageUtil.parse("&6Arena Setup:"));
                    p.sendMessage(MessageUtil.parse("  &f/event setarena <name> <mode> corner1 &8— stand at first corner"));
                    p.sendMessage(MessageUtil.parse("  &f/event setarena <name> <mode> corner2 &8— stand at opposite corner"));
                    p.sendMessage(MessageUtil.parse("  &f/event setarena <name> sethill &8— set KOTH hill point (optional)"));
                    p.sendMessage(MessageUtil.parse("&7Modes: &e" + String.join(", ", MODES)));
                    return true;
                }

                String arenaName = args[1];
                String mode      = args[2].toLowerCase();
                String corner    = args[3].toLowerCase();

                if (!MODES.contains(mode)) {
                    p.sendMessage(MessageUtil.parse("&cUnknown mode: &e" + mode + "&c. Valid: &f" + String.join(", ", MODES)));
                    return true;
                }

                if (corner.equals("corner1")) {
                    plugin.getArenaManager().beginSetup(arenaName, mode, p.getLocation());
                    p.sendMessage(MessageUtil.parse("&aCorner 1 set for &e" + arenaName + " &8[&6" + mode + "&8]&a! Now set corner2."));
                } else if (corner.equals("corner2")) {
                    if (!plugin.getArenaManager().hasPendingC1(arenaName)) {
                        p.sendMessage(MessageUtil.parse("&cSet corner1 first: &f/event setarena " + arenaName + " " + mode + " corner1"));
                    } else {
                        Arena a = plugin.getArenaManager().finishSetup(arenaName, p.getLocation());
                        if (a != null) {
                            p.sendMessage(MessageUtil.parse("&aArena &e" + arenaName + " &8[&6" + mode + "&8] &acreated and saved!"));
                            if (mode.equals("koth"))
                                p.sendMessage(MessageUtil.parse("&7Tip: Set a custom hill point with &f/event setarena " + arenaName + " sethill"));
                        } else {
                            p.sendMessage(MessageUtil.parse("&cError — set corner1 first."));
                        }
                    }
                } else {
                    p.sendMessage(MessageUtil.parse("&cUse &fcorner1 &cor &fcorner2&c."));
                }
            }

            case "reload" -> {
                if (!sender.hasPermission("aep.admin")) { sender.sendMessage(MessageUtil.parse("&cNo permission.")); return true; }
                plugin.getArenaManager().reload();
                sender.sendMessage(MessageUtil.parse("&aConfig and arenas reloaded!"));
            }

            default -> help(sender);
        }
        return true;
    }

    private void help(CommandSender s) {
        s.sendMessage(MessageUtil.parse("&6&l=== AdvancedEventsPro ==="));
        s.sendMessage(MessageUtil.parse("&a/event join [mode] &8— &7Join an open event"));
        s.sendMessage(MessageUtil.parse("&a/event leave &8— &7Leave your current event"));
        s.sendMessage(MessageUtil.parse("&a/event list &8— &7Show arenas and active events"));
        s.sendMessage(MessageUtil.parse("&a/event learn [mode] &8— &7View mode guide"));
        if (s.hasPermission("aep.admin")) {
            s.sendMessage(MessageUtil.parse("&c/event start <mode> &8— &7Start an event"));
            s.sendMessage(MessageUtil.parse("&c/event stop <mode|all> &8— &7Stop event(s)"));
            s.sendMessage(MessageUtil.parse("&c/event setarena <name> <mode> <corner1|corner2>"));
            s.sendMessage(MessageUtil.parse("&c/event setarena <name> sethill &8— &7KOTH hill point"));
            s.sendMessage(MessageUtil.parse("&c/event admin &8— &7Admin GUI"));
            s.sendMessage(MessageUtil.parse("&c/event reload &8— &7Reload config"));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("join", "leave", "list", "learn"));
            if (s.hasPermission("aep.admin")) subs.addAll(List.of("start", "stop", "admin", "setarena", "reload"));
            return filter(subs, args[0]);
        }
        if (args.length == 2) {
            if (args[0].equalsIgnoreCase("join")  || args[0].equalsIgnoreCase("start")
             || args[0].equalsIgnoreCase("stop")  || args[0].equalsIgnoreCase("learn"))
                return filter(MODES, args[1]);
            if (args[0].equalsIgnoreCase("setarena"))
                return filter(plugin.getArenaManager().getAll().stream().map(Arena::getName).toList(), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setarena"))
            return filter(MODES, args[2]);
        if (args.length == 4 && args[0].equalsIgnoreCase("setarena"))
            return filter(List.of("corner1", "corner2", "sethill"), args[3]);
        return List.of();
    }

    private List<String> filter(List<String> list, String prefix) {
        return list.stream().filter(s -> s.toLowerCase().startsWith(prefix.toLowerCase())).toList();
    }
}
