package com.aep.command;

import com.aep.AdvancedEventsPro;
import com.aep.util.MessageUtil;
import org.bukkit.command.CommandSender;

public class LearnCommand {

    private final AdvancedEventsPro plugin;

    public LearnCommand(AdvancedEventsPro plugin) { this.plugin = plugin; }

    public void show(CommandSender s, String mode) {
        switch (mode.toLowerCase()) {
            case "pvp" -> {
                s.sendMessage(MessageUtil.parse("&c&l=== PvP ==="));
                s.sendMessage(MessageUtil.parse("&7Last player alive wins. Full PvP enabled."));
                s.sendMessage(MessageUtil.parse("&7Join: &a/event join pvp"));
                s.sendMessage(MessageUtil.parse("&7Arena: any open area. Config: &epvp.min-players"));
            }
            case "koth" -> {
                s.sendMessage(MessageUtil.parse("&6&l=== King of the Hill ==="));
                s.sendMessage(MessageUtil.parse("&7Stand on the hill alone. Hold it for the required time to win."));
                s.sendMessage(MessageUtil.parse("&7If contested (2+ players), capture pauses."));
                s.sendMessage(MessageUtil.parse("&7Join: &a/event join koth"));
                s.sendMessage(MessageUtil.parse("&7Config: &ekoth.capture-time &7(secs), &ekoth.hill-radius"));
                s.sendMessage(MessageUtil.parse("&7Tip: Set a custom hill with &f/event setarena <n> sethill"));
            }
            case "sumo" -> {
                s.sendMessage(MessageUtil.parse("&b&l=== Sumo ==="));
                s.sendMessage(MessageUtil.parse("&7Push opponents off the platform with your Knockback V stick."));
                s.sendMessage(MessageUtil.parse("&7You can't die from hits — only falling eliminates you."));
                s.sendMessage(MessageUtil.parse("&7Join: &a/event join sumo"));
                s.sendMessage(MessageUtil.parse("&7Config: &esumo.void-y &7(Y level = elimination)"));
            }
            case "tntrun" -> {
                s.sendMessage(MessageUtil.parse("&c&l=== TNT Run ==="));
                s.sendMessage(MessageUtil.parse("&7The floor breaks under your feet. Keep running!"));
                s.sendMessage(MessageUtil.parse("&7Fall through the floor = eliminated."));
                s.sendMessage(MessageUtil.parse("&7Join: &a/event join tntrun"));
                s.sendMessage(MessageUtil.parse("&7Config: &etntrun.block-delay &7(ticks before block breaks)"));
                s.sendMessage(MessageUtil.parse("&7Arena tip: Build with &esnow blocks&7 or &eglass&7."));
            }
            case "spleef" -> {
                s.sendMessage(MessageUtil.parse("&a&l=== Spleef ==="));
                s.sendMessage(MessageUtil.parse("&7Break blocks under opponents with your diamond shovel."));
                s.sendMessage(MessageUtil.parse("&7Fall = eliminated. Last alive wins."));
                s.sendMessage(MessageUtil.parse("&7Join: &a/event join spleef"));
                s.sendMessage(MessageUtil.parse("&7Arena tip: Build floor with &esnow blocks&7 or &eice&7."));
            }
            case "bowspleef" -> {
                s.sendMessage(MessageUtil.parse("&e&l=== Bow Spleef ==="));
                s.sendMessage(MessageUtil.parse("&7Shoot arrows to break blocks under your opponents."));
                s.sendMessage(MessageUtil.parse("&7Infinity bow — just keep 1 arrow in your inventory."));
                s.sendMessage(MessageUtil.parse("&7Join: &a/event join bowspleef"));
                s.sendMessage(MessageUtil.parse("&7Arena tip: Any breakable block floor works."));
            }
            case "oneinthequiver" -> {
                s.sendMessage(MessageUtil.parse("&d&l=== One in the Quiver ==="));
                s.sendMessage(MessageUtil.parse("&7Power V bow with &61 arrow&7. Bow kill = arrow refill."));
                s.sendMessage(MessageUtil.parse("&7Dying is &eNOT &7elimination — you respawn and keep fighting!"));
                s.sendMessage(MessageUtil.parse("&7First to reach &6" + plugin.getConfig().getInt("oneinthequiver.kills-to-win", 5) + " &7bow kills wins."));
                s.sendMessage(MessageUtil.parse("&7Join: &a/event join oneinthequiver"));
                s.sendMessage(MessageUtil.parse("&7Config: &eoneinthequiver.kills-to-win"));
            }
            default -> {
                s.sendMessage(MessageUtil.parse("&6Available modes:"));
                s.sendMessage(MessageUtil.parse("  &a/event learn pvp"));
                s.sendMessage(MessageUtil.parse("  &a/event learn koth"));
                s.sendMessage(MessageUtil.parse("  &a/event learn sumo"));
                s.sendMessage(MessageUtil.parse("  &a/event learn tntrun"));
                s.sendMessage(MessageUtil.parse("  &a/event learn spleef"));
                s.sendMessage(MessageUtil.parse("  &a/event learn bowspleef"));
                s.sendMessage(MessageUtil.parse("  &a/event learn oneinthequiver"));
            }
        }
    }
}
