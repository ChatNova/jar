package com.aep.listener;

import com.aep.AdvancedEventsPro;
import com.aep.event.EventInstance;
import com.aep.event.EventState;
import com.aep.event.modes.EventMode;
import com.aep.util.MessageUtil;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public class EventListener implements Listener {

    private final AdvancedEventsPro plugin;

    public EventListener(AdvancedEventsPro plugin) { this.plugin = plugin; }

    // ── Death ─────────────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        EventInstance inst = plugin.getEventManager().getPlayerInstance(player);
        if (inst == null || inst.getState() != EventState.RUNNING) return;

        EventMode mode = inst.getMode();
        if (!mode.isParticipant(player)) return;
        if (!mode.eliminateOnDeath()) return; // OITQ / Sumo handle their own deaths
        if (!mode.isAlive(player)) return;

        event.setDeathMessage(null);
        event.getDrops().clear();
        event.setDroppedExp(0);

        mode.eliminate(player);
    }

    // ── Respawn — send spectators back to arena ───────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        EventInstance inst = plugin.getEventManager().getPlayerInstance(player);
        if (inst == null || inst.getState() != EventState.RUNNING) return;
        EventMode mode = inst.getMode();
        if (!mode.isParticipant(player) || !mode.eliminateOnDeath()) return;

        event.setRespawnLocation(inst.getArena().getCenter());
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            player.setGameMode(GameMode.SPECTATOR), 1L);
    }

    // ── Disconnect — auto-leave ───────────────────────────────────────────────
    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getEventManager().leave(event.getPlayer());
    }

    // ── Hunger disabled during events ─────────────────────────────────────────
    @EventHandler
    public void onHunger(FoodLevelChangeEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        EventInstance inst = plugin.getEventManager().getPlayerInstance(player);
        if (inst != null && inst.getState() == EventState.RUNNING
            && inst.getMode().isParticipant(player)) {
            event.setCancelled(true);
        }
    }

    // ── Block breaking — only allowed in spleef modes ─────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        EventInstance inst = plugin.getEventManager().getPlayerInstance(player);
        if (inst == null || inst.getState() != EventState.RUNNING) return;
        EventMode mode = inst.getMode();
        if (!mode.isParticipant(player)) return;
        String id = mode.getId();
        if (!id.equals("spleef") && !id.equals("bowspleef")) event.setCancelled(true);
    }

    // ── PvP protection — spectators and non-participants can't be hit ─────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (victim.getGameMode() == GameMode.SPECTATOR) { event.setCancelled(true); return; }
        EventInstance inst = plugin.getEventManager().getPlayerInstance(victim);
        if (inst != null && inst.getState() == EventState.RUNNING
            && !inst.getMode().isParticipant(victim)) {
            event.setCancelled(true);
        }
    }
}
