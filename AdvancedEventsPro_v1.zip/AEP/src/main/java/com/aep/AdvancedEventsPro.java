package com.aep;

import com.aep.arena.ArenaManager;
import com.aep.command.EventCommand;
import com.aep.discord.DiscordWebhook;
import com.aep.event.EventManager;
import com.aep.gui.AdminGUI;
import com.aep.listener.EventListener;
import com.aep.reward.RewardManager;
import com.aep.scoreboard.ScoreboardManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class AdvancedEventsPro extends JavaPlugin {

    private ArenaManager     arenaManager;
    private EventManager     eventManager;
    private RewardManager    rewardManager;
    private DiscordWebhook   discordWebhook;
    private AdminGUI         adminGUI;
    private ScoreboardManager scoreboardManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        arenaManager      = new ArenaManager(this);
        discordWebhook    = new DiscordWebhook(this);
        rewardManager     = new RewardManager(this);
        eventManager      = new EventManager(this);
        adminGUI          = new AdminGUI(this);
        scoreboardManager = new ScoreboardManager(this);

        Bukkit.getPluginManager().registerEvents(new EventListener(this), this);
        Bukkit.getPluginManager().registerEvents(adminGUI, this);

        EventCommand cmd = new EventCommand(this);
        getCommand("event").setExecutor(cmd);
        getCommand("event").setTabCompleter(cmd);

        // Scoreboard refresh every 2s
        Bukkit.getScheduler().runTaskTimer(this, scoreboardManager::updateAll, 40L, 40L);

        if (getConfig().getBoolean("events.auto", true)) eventManager.startAutoTimer();

        getLogger().info("AdvancedEventsPro enabled. 7 modes | Multi-event support | /event join <mode>");
    }

    @Override
    public void onDisable() {
        if (eventManager != null) eventManager.stopAutoTimer();
        getLogger().info("AdvancedEventsPro disabled.");
    }

    public ArenaManager      getArenaManager()       { return arenaManager; }
    public EventManager      getEventManager()       { return eventManager; }
    public RewardManager     getRewardManager()      { return rewardManager; }
    public DiscordWebhook    getDiscordWebhook()     { return discordWebhook; }
    public AdminGUI          getAdminGUI()           { return adminGUI; }
    public ScoreboardManager getScoreboardManager()  { return scoreboardManager; }
}
