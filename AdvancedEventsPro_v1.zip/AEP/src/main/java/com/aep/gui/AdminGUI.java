package com.aep.gui;

import com.aep.AdvancedEventsPro;
import com.aep.arena.Arena;
import com.aep.event.EventInstance;
import com.aep.event.EventState;
import com.aep.util.MessageUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class AdminGUI implements Listener {

    private final AdvancedEventsPro plugin;
    private static final String TITLE = "§5§lEvents Pro §8- Admin";

    public AdminGUI(AdvancedEventsPro plugin) { this.plugin = plugin; }

    public void open(Player admin) {
        Inventory gui = Bukkit.createInventory(null, 54, TITLE);

        // Active events status
        List<String> statusLore = new ArrayList<>();
        statusLore.add("&7Active events:");
        for (EventInstance inst : plugin.getEventManager().getInstances().values()) {
            String st = inst.getState() == EventState.RUNNING ? "&cRunning"
                      : inst.getState() == EventState.WAITING ? "&eWaiting" : "&7Idle";
            statusLore.add("  &f" + inst.getMode().getDisplayName() + " &8@ &f" + inst.getArena().getName() + " &8— " + st);
        }
        if (plugin.getEventManager().getInstances().isEmpty()) statusLore.add("  &8None running");
        gui.setItem(4, item(Material.CLOCK, "&7Event Status", statusLore.toArray(new String[0])));

        // Start buttons per mode
        int[] slots = {19, 20, 21, 22, 23, 24, 25};
        String[] modes = {"pvp", "koth", "sumo", "tntrun", "spleef", "bowspleef", "oneinthequiver"};
        Material[] mats = {Material.IRON_SWORD, Material.GOLDEN_HELMET, Material.STICK,
            Material.TNT, Material.DIAMOND_SHOVEL, Material.BOW, Material.ARROW};
        String[] names = {"&cPvP", "&6KOTH", "&bSumo", "&cTNT Run", "&aSpleef", "&eBow Spleef", "&dOne in the Quiver"};

        for (int i = 0; i < modes.length; i++) {
            boolean active = plugin.getEventManager().hasActive(modes[i]);
            boolean hasArena = !plugin.getArenaManager().getForMode(modes[i]).isEmpty();
            String status = active ? "&cAlready running" : hasArena ? "&aClick to start" : "&cNo arena configured";
            gui.setItem(slots[i], item(mats[i], names[i],
                "&7Mode: &f" + modes[i],
                status));
        }

        // Stop all
        gui.setItem(40, item(Material.RED_CONCRETE, "&c■ Stop All Events", "&7Force stop every active event."));

        // Arenas
        List<String> arenaLore = new ArrayList<>();
        arenaLore.add("&7Configured arenas:");
        for (Arena a : plugin.getArenaManager().getAll())
            arenaLore.add("  &f" + a.getName() + " &8[&6" + a.getMode() + "&8] " + (a.isEnabled() ? "&aEnabled" : "&cDisabled"));
        if (plugin.getArenaManager().getAll().isEmpty()) arenaLore.add("  &8None");
        arenaLore.add(""); arenaLore.add("&7Use &f/event setarena");
        gui.setItem(31, item(Material.COMPASS, "&b◈ Arenas", arenaLore.toArray(new String[0])));

        // Reload
        gui.setItem(33, item(Material.COMMAND_BLOCK, "&7↺ Reload Config", "&7Reload arenas and config.yml"));

        // Close
        gui.setItem(49, item(Material.BARRIER, "&c✖ Close", "&7Close this menu."));

        // Border
        ItemStack glass = item(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 9; i++) { gui.setItem(i, glass); gui.setItem(45 + i, glass); }
        for (int i = 1; i < 5; i++) { gui.setItem(i * 9, glass); gui.setItem(i * 9 + 8, glass); }

        admin.openInventory(gui);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals(TITLE)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player admin)) return;
        if (!admin.hasPermission("aep.admin")) return;

        int[] slots = {19, 20, 21, 22, 23, 24, 25};
        String[] modes = {"pvp", "koth", "sumo", "tntrun", "spleef", "bowspleef", "oneinthequiver"};

        for (int i = 0; i < slots.length; i++) {
            if (e.getRawSlot() == slots[i]) {
                admin.closeInventory();
                boolean ok = plugin.getEventManager().announceJoin(modes[i]);
                admin.sendMessage(MessageUtil.parse(ok
                    ? "&aAnnounced &e" + modes[i] + "&a!"
                    : "&cFailed — check arena or already running."));
                return;
            }
        }

        switch (e.getRawSlot()) {
            case 40 -> {
                admin.closeInventory();
                plugin.getEventManager().forceStopAll(admin.getName());
            }
            case 33 -> {
                plugin.getArenaManager().reload();
                admin.sendMessage(MessageUtil.parse("&aReloaded!"));
                admin.closeInventory();
            }
            case 49 -> admin.closeInventory();
        }
    }

    private ItemStack item(Material mat, String name, String... lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(MessageUtil.parse(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(MessageUtil.parse(s));
        meta.lore(l);
        item.setItemMeta(meta);
        return item;
    }
}
