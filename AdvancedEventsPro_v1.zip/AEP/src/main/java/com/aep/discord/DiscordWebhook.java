package com.aep.discord;

import com.aep.AdvancedEventsPro;
import org.bukkit.Bukkit;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class DiscordWebhook {

    private final AdvancedEventsPro plugin;

    public DiscordWebhook(AdvancedEventsPro plugin) { this.plugin = plugin; }

    public void send(String message) {
        if (!plugin.getConfig().getBoolean("discord.enabled", false)) return;
        String webhookUrl = plugin.getConfig().getString("discord.webhook-url", "");
        if (webhookUrl.isEmpty()) return;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                URL url = new URL(webhookUrl);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json");
                con.setDoOutput(true);
                String json = "{\"content\":\"" + message.replace("\"", "\\\"") + "\"}";
                try (OutputStream os = con.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }
                con.getResponseCode(); // fire request
                con.disconnect();
            } catch (Exception e) {
                plugin.getLogger().warning("[AEP] Discord webhook failed: " + e.getMessage());
            }
        });
    }
}
