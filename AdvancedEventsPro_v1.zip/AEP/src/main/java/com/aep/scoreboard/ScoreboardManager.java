package com.aep.scoreboard;

import com.aep.AdvancedEventsPro;
import com.aep.event.EventInstance;
import com.aep.event.EventState;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

public class ScoreboardManager {

    private final AdvancedEventsPro plugin;

    public ScoreboardManager(AdvancedEventsPro plugin) { this.plugin = plugin; }

    public void updateAll() { for (Player p : Bukkit.getOnlinePlayers()) update(p); }

    public void update(Player player) {
        org.bukkit.scoreboard.ScoreboardManager mgr = Bukkit.getScoreboardManager();
        Scoreboard board = mgr.getNewScoreboard();
        Objective obj = board.registerNewObjective("aep", Criteria.DUMMY,
            color("&6&lEvents Pro"));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        // Find if this player is in any event
        EventInstance inst = plugin.getEventManager().getPlayerInstance(player);

        int line = 14;
        set(obj, board, "&8────────────────", line--, 0);

        if (inst == null) {
            // Not in an event - show open events
            boolean anyOpen = false;
            for (EventInstance i : plugin.getEventManager().getInstances().values()) {
                if (i.getState() == EventState.WAITING) {
                    set(obj, board, "&e" + i.getMode().getDisplayName(), line--, line);
                    set(obj, board, "&a/event join " + i.getModeId(), line--, line);
                    set(obj, board, "&7" + i.getWaiting().size() + " waiting | " + i.getJoinCountdown() + "s", line--, line);
                    set(obj, board, " ", line--, line);
                    anyOpen = true;
                }
            }
            if (!anyOpen) {
                set(obj, board, "&7No active events", line--, 1);
                set(obj, board, "&7Wait for an", line--, 2);
                set(obj, board, "&7announcement!", line--, 3);
            }
        } else if (inst.getState() == EventState.WAITING) {
            set(obj, board, "&e" + inst.getMode().getDisplayName(), line--, 1);
            set(obj, board, "&7Starting in:", line--, 2);
            set(obj, board, "&6" + inst.getJoinCountdown() + "s", line--, 3);
            set(obj, board, "&7Players: &f" + inst.getWaiting().size(), line--, 4);
            set(obj, board, "&aYou are queued!", line--, 5);
        } else if (inst.getState() == EventState.RUNNING) {
            boolean alive = inst.isAlive(player);
            set(obj, board, "&6" + inst.getMode().getDisplayName(), line--, 1);
            set(obj, board, "&7Arena: &f" + inst.getArena().getName(), line--, 2);
            set(obj, board, "&7Alive: &f" + inst.getMode().getAlive().size(), line--, 3);
            set(obj, board, alive ? "&aYou are competing!" : "&7Spectating", line--, 4);
        }

        set(obj, board, "&8────────────────", line--, 99);
        player.setScoreboard(board);
    }

    private void set(Objective obj, Scoreboard board, String text, int score, int uid) {
        // Unique entry: pad with invisible §r chars to avoid duplicate key errors
        StringBuilder pad = new StringBuilder();
        for (int i = 0; i < uid; i++) pad.append("§r");
        Score s = obj.getScore(text.replace("&", "§") + pad);
        s.setScore(score);
    }

    private net.kyori.adventure.text.Component color(String s) {
        return net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacyAmpersand().deserialize(s);
    }
}
